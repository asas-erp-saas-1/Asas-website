import { Link } from "react-router-dom";
import { TrendingUp, BarChart3, Shield, Globe, ArrowRight, CheckCircle, Percent, Building2 } from "lucide-react";
import { useScrollFade } from "@/hooks/useScrollFade";
import { properties } from "@/data/properties";
import PropertyCard from "@/components/PropertyCard";

function SectionFade({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, isVisible } = useScrollFade(0.15);
  return (
    <div ref={ref} className={`section-fade ${isVisible ? "visible" : ""} ${className}`}>
      {children}
    </div>
  );
}

export default function Investment() {
  return (
    <main className="pt-[80px]">
      {/* Hero */}
      <section className="py-16 md:py-24" style={{ background: "linear-gradient(135deg, #04395E 0%, #002845 100%)" }}>
        <div className="max-w-[1200px] mx-auto px-6 text-center">
          <SectionFade>
            <p className="text-xs uppercase tracking-[0.15em] mb-3" style={{ color: "var(--cool-mint)" }}>Smart Investing</p>
            <h1 className="font-display text-3xl md:text-5xl text-white mb-4">
              Investment Advisory
            </h1>
            <p className="text-base max-w-2xl mx-auto" style={{ color: "rgba(255,255,255,0.7)" }}>
              Data-driven insights and expert guidance for building a profitable real estate portfolio in Algeria
            </p>
          </SectionFade>
        </div>
      </section>

      {/* Market Overview */}
      <section className="py-20" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-14">
              <h2 className="font-display text-3xl md:text-4xl mb-4" style={{ color: "var(--deep-teal)" }}>
                Why Invest in Algerian Real Estate?
              </h2>
              <p className="text-lg max-w-2xl mx-auto" style={{ color: "var(--text-secondary)" }}>
                Algeria's luxury property market offers compelling opportunities for informed investors
              </p>
            </div>
          </SectionFade>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: TrendingUp, title: "8-12% Annual Growth", desc: "Luxury property values in prime coastal areas have consistently appreciated 8-12% annually over the past decade." },
              { icon: Percent, title: "Rental Yield 6-9%", desc: "Premium properties in Oran and Algiers generate attractive rental yields, particularly during the summer season." },
              { icon: Shield, title: "Stable Market", desc: "Algeria's property market has shown remarkable resilience, with limited volatility compared to regional markets." },
              { icon: Globe, title: "Tourism Growth", desc: "With increasing tourism and foreign investment, demand for luxury accommodation continues to rise." },
            ].map((item, idx) => (
              <SectionFade key={idx}>
                <div className="bg-white p-8 rounded text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-lg h-full">
                  <div className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: "var(--deep-teal)" }}>
                    <item.icon size={24} className="text-white" />
                  </div>
                  <h4 className="font-display text-lg mb-2" style={{ color: "var(--deep-teal)" }}>{item.title}</h4>
                  <p className="text-sm" style={{ color: "var(--text-secondary)" }}>{item.desc}</p>
                </div>
              </SectionFade>
            ))}
          </div>
        </div>
      </section>

      {/* Investment Calculator */}
      <section className="py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <SectionFade>
              <div>
                <h2 className="font-display text-3xl md:text-4xl mb-6" style={{ color: "var(--deep-teal)" }}>
                  Investment Performance
                </h2>
                <div className="space-y-6">
                  {[
                    { label: "Oran Coastal Villas", growth: "12%", yield: "8.5%", color: "var(--deep-teal)" },
                    { label: "Algiers Bay Properties", growth: "10%", yield: "7.2%", color: "var(--soft-sage)" },
                    { label: "Mountain View Homes", growth: "9%", yield: "6.8%", color: "var(--warm-sage)" },
                    { label: "City Center Apartments", growth: "8%", yield: "9.1%", color: "var(--deep-navy)" },
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-center gap-4">
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1.5">
                          <span className="text-sm font-medium" style={{ color: "var(--text-primary)" }}>{item.label}</span>
                          <span className="text-xs" style={{ color: "var(--taupe)" }}>Annual Growth: {item.growth} | Yield: {item.yield}</span>
                        </div>
                        <div className="h-2.5 rounded-full overflow-hidden" style={{ background: "var(--mist)" }}>
                          <div
                            className="h-full rounded-full transition-all duration-1000"
                            style={{ width: `${parseInt(item.growth) * 8}%`, background: item.color }}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 p-5 rounded" style={{ background: "var(--light-mint)" }}>
                  <div className="flex items-start gap-3">
                    <BarChart3 size={20} className="mt-0.5 flex-shrink-0" style={{ color: "var(--deep-teal)" }} />
                    <div>
                      <p className="text-sm font-medium mb-1" style={{ color: "var(--deep-teal)" }}>Market Insight</p>
                      <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
                        Prime coastal properties in Oran have shown the strongest appreciation, driven by limited supply and increasing demand from both local and international buyers.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </SectionFade>

            <SectionFade>
              <div
                className="p-8"
                style={{ background: "var(--light-mint)", borderRadius: 4 }}
              >
                <h3 className="font-display text-xl mb-6" style={{ color: "var(--deep-teal)" }}>
                  Investment Criteria
                </h3>
                <div className="space-y-4">
                  {[
                    "Minimum investment: 50M DZD",
                    "Expected ROI: 6-12% annually",
                    "Typical holding period: 3-7 years",
                    "Rental management available",
                    "Full legal and tax advisory",
                    "Portfolio diversification support",
                  ].map((criteria, idx) => (
                    <div key={idx} className="flex items-start gap-3">
                      <CheckCircle size={16} className="mt-0.5 flex-shrink-0" style={{ color: "var(--soft-sage)" }} />
                      <span className="text-sm" style={{ color: "var(--text-primary)" }}>{criteria}</span>
                    </div>
                  ))}
                </div>

                <Link
                  to="/investor"
                  className="btn-primary w-full mt-8"
                >
                  Become an Investor
                  <ArrowRight size={16} className="ml-2" />
                </Link>
              </div>
            </SectionFade>
          </div>
        </div>
      </section>

      {/* Featured Investment Properties */}
      <section className="py-20" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-14">
              <h2 className="font-display text-3xl md:text-4xl mb-4" style={{ color: "var(--deep-teal)" }}>
                Investment Opportunities
              </h2>
              <p className="text-lg max-w-2xl mx-auto" style={{ color: "var(--text-secondary)" }}>
                Properties with strong appreciation potential and rental yield
              </p>
            </div>
          </SectionFade>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties.filter(p => p.priceValue >= 100000000).map((property) => (
              <SectionFade key={property.id}>
                <PropertyCard property={property} />
              </SectionFade>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16" style={{ background: "linear-gradient(90deg, #04395E 0%, #013A63 100%)" }}>
        <div className="max-w-[1200px] mx-auto px-6 text-center">
          <SectionFade>
            <Building2 size={48} className="mx-auto mb-4 text-white opacity-60" />
            <h3 className="font-display text-2xl md:text-3xl text-white mb-4">
              Start Building Your Portfolio
            </h3>
            <p className="text-base max-w-xl mx-auto mb-8" style={{ color: "rgba(255,255,255,0.85)" }}>
              Schedule a consultation with our investment advisors to discuss your goals and explore tailored opportunities.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/investor" className="btn-secondary">
                Investor Program
              </Link>
              <Link to="/contact" className="inline-flex items-center justify-center px-8 py-3 text-base font-medium transition-all duration-300 border-2 hover:bg-white hover:text-[var(--deep-teal)]" style={{ borderColor: "rgba(255,255,255,0.4)", color: "white", borderRadius: 2 }}>
                Contact Us
              </Link>
            </div>
          </SectionFade>
        </div>
      </section>
    </main>
  );
}
