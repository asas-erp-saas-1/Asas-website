import { CheckCircle, Award, Phone, Mail } from "lucide-react";
import { agents } from "@/data/properties";
import { useScrollFade } from "@/hooks/useScrollFade";
import { useCountUp } from "@/hooks/useCountUp";

function SectionFade({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, isVisible } = useScrollFade(0.15);
  return (
    <div ref={ref} className={`section-fade ${isVisible ? "visible" : ""} ${className}`}>
      {children}
    </div>
  );
}

function StatCounter({ end, suffix, label }: { end: number; suffix: string; label: string }) {
  const { count, ref } = useCountUp(end, 2000);
  return (
    <div ref={ref} className="text-center">
      <div className="font-display text-4xl md:text-[42px]" style={{ color: "var(--deep-teal)" }}>
        {count}{suffix}
      </div>
      <p className="text-sm mt-1" style={{ color: "var(--text-secondary)" }}>{label}</p>
    </div>
  );
}

export default function About() {
  const milestones = [
    { year: "2011", title: "Founded", desc: "ASAS Real Estate was established in Oran with a vision to transform luxury property services in Algeria." },
    { year: "2014", title: "Algiers Office", desc: "Opened our second office in Algiers to serve the capital's growing demand for premium real estate." },
    { year: "2017", title: "100th Sale", desc: "Celebrated our 100th successful property transaction, cementing our reputation for excellence." },
    { year: "2020", title: "Digital Transformation", desc: "Launched our digital platform bringing virtual tours and online consultations to Algerian clients." },
    { year: "2023", title: "Market Leader", desc: "Recognized as the leading luxury real estate agency in Western Algeria by industry peers." },
    { year: "2026", title: "Continued Growth", desc: "Expanded our portfolio to over 127 properties sold with 98% client satisfaction rate." },
  ];

  return (
    <main className="pt-[80px]">
      {/* Hero */}
      <section className="py-16 md:py-24" style={{ background: "linear-gradient(135deg, #04395E 0%, #002845 100%)" }}>
        <div className="max-w-[1200px] mx-auto px-6 text-center">
          <SectionFade>
            <p className="text-xs uppercase tracking-[0.15em] mb-3" style={{ color: "var(--cool-mint)" }}>Our Story</p>
            <h1 className="font-display text-3xl md:text-5xl text-white mb-4">
              About ASAS Real Estate
            </h1>
            <p className="text-base max-w-2xl mx-auto" style={{ color: "rgba(255,255,255,0.7)" }}>
              Algeria's trusted partner in luxury real estate since 2011. We transform property dreams into reality through expertise, integrity, and personalized service.
            </p>
          </SectionFade>
        </div>
      </section>

      {/* Founder's Story */}
      <section className="py-20" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <SectionFade>
              <div className="rounded overflow-hidden" style={{ aspectRatio: "4/5", maxHeight: 560 }}>
                <img
                  src="/images/agent-rachid.jpg"
                  alt="Rachid Mansour, Managing Director"
                  className="w-full h-full object-cover object-top"
                  loading="lazy"
                />
              </div>
            </SectionFade>

            <SectionFade>
              <div>
                <p className="text-xs uppercase tracking-[0.15em] mb-3" style={{ color: "var(--soft-sage)" }}>Managing Director</p>
                <h2 className="font-display text-3xl md:text-4xl mb-4" style={{ color: "var(--deep-teal)" }}>
                  Rachid Mansour
                </h2>
                <p className="text-base leading-relaxed mb-4" style={{ color: "var(--text-primary)" }}>
                  With over 25 years of experience in Algerian and international real estate markets, Rachid founded ASAS Real Estate with a singular vision: to bring world-class property services to Algeria's discerning clientele.
                </p>
                <p className="text-base leading-relaxed mb-4" style={{ color: "var(--text-primary)" }}>
                  His deep understanding of Mediterranean luxury markets, combined with an extensive network of property developers, architects, and legal experts, has positioned ASAS as the agency of choice for high-net-worth individuals seeking exceptional properties.
                </p>
                <p className="text-base leading-relaxed mb-6" style={{ color: "var(--text-primary)" }}>
                  "Every client deserves transparency, expertise, and a partner who truly understands their vision. That is the ASAS promise."
                </p>

                <div className="flex flex-wrap gap-4 mb-6">
                  <a href="tel:+213550000004" className="flex items-center gap-2 text-sm" style={{ color: "var(--deep-teal)" }}>
                    <Phone size={16} /> +213 550 000 004
                  </a>
                  <a href="mailto:rachid@asas-realestate.dz" className="flex items-center gap-2 text-sm" style={{ color: "var(--deep-teal)" }}>
                    <Mail size={16} /> rachid@asas-realestate.dz
                  </a>
                </div>

                <div className="flex flex-wrap gap-3">
                  {[
                    "25+ Years Experience",
                    "Founder & Director",
                    "Market Expert",
                    "Client-Focused",
                  ].map((tag) => (
                    <span
                      key={tag}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm"
                      style={{ background: "var(--mist)", color: "var(--deep-teal)", borderRadius: 2 }}
                    >
                      <Award size={12} /> {tag}
                    </span>
                  ))}
                </div>
              </div>
            </SectionFade>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-14">
              <h2 className="font-display text-3xl md:text-4xl mb-4" style={{ color: "var(--deep-teal)" }}>Our Journey</h2>
              <p className="text-lg max-w-2xl mx-auto" style={{ color: "var(--text-secondary)" }}>
                From a single office in Oran to becoming Algeria's premier luxury real estate agency
              </p>
            </div>
          </SectionFade>

          <div className="relative">
            {/* Center Line */}
            <div className="absolute left-1/2 top-0 bottom-0 w-px -translate-x-1/2 hidden md:block" style={{ background: "var(--silver-sage)" }} />

            <div className="space-y-12">
              {milestones.map((milestone, idx) => (
                <SectionFade key={idx}>
                  <div className={`flex flex-col md:flex-row items-center gap-6 ${idx % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}>
                    <div className={`flex-1 ${idx % 2 === 0 ? "md:text-right" : "md:text-left"}`}>
                      <span className="font-display text-3xl block mb-1" style={{ color: "var(--warm-sage)" }}>{milestone.year}</span>
                      <h4 className="font-display text-lg mb-1" style={{ color: "var(--deep-teal)" }}>{milestone.title}</h4>
                      <p className="text-sm" style={{ color: "var(--text-secondary)" }}>{milestone.desc}</p>
                    </div>
                    <div className="w-4 h-4 rounded-full border-4 flex-shrink-0 hidden md:block" style={{ background: "white", borderColor: "var(--deep-teal)" }} />
                    <div className="flex-1" />
                  </div>
                </SectionFade>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-14">
              <h2 className="font-display text-3xl md:text-4xl mb-4" style={{ color: "var(--deep-teal)" }}>Meet Our Team</h2>
              <p className="text-lg max-w-2xl mx-auto" style={{ color: "var(--text-secondary)" }}>
                Experienced professionals dedicated to finding your perfect property
              </p>
            </div>
          </SectionFade>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {agents.map((agent) => (
              <SectionFade key={agent.id}>
                <div className="bg-white rounded overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-lg">
                  <div style={{ aspectRatio: "1" }}>
                    <img src={agent.image} alt={agent.name} className="w-full h-full object-cover" loading="lazy" />
                  </div>
                  <div className="p-6">
                    <h4 className="font-display text-lg mb-1" style={{ color: "var(--deep-teal)" }}>{agent.name}</h4>
                    <p className="text-sm mb-3" style={{ color: "var(--taupe)" }}>{agent.role}</p>
                    <p className="text-sm mb-4 leading-relaxed" style={{ color: "var(--text-secondary)" }}>{agent.bio}</p>
                    <div className="space-y-1.5">
                      <a href={`tel:${agent.phone}`} className="flex items-center gap-2 text-xs" style={{ color: "var(--deep-teal)" }}>
                        <Phone size={12} /> {agent.phone}
                      </a>
                      <a href={`mailto:${agent.email}`} className="flex items-center gap-2 text-xs" style={{ color: "var(--deep-teal)" }}>
                        <Mail size={12} /> {agent.email}
                      </a>
                    </div>
                  </div>
                </div>
              </SectionFade>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16" style={{ background: "linear-gradient(135deg, #04395E 0%, #002845 100%)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <StatCounter end={127} suffix="+" label="Properties Sold" />
            <StatCounter end={500} suffix="+" label="Happy Clients" />
            <StatCounter end={15} suffix="+" label="Years of Service" />
            <StatCounter end={4} suffix="" label="Expert Agents" />
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-14">
              <h2 className="font-display text-3xl md:text-4xl mb-4" style={{ color: "var(--deep-teal)" }}>Our Values</h2>
              <p className="text-lg max-w-2xl mx-auto" style={{ color: "var(--text-secondary)" }}>
                The principles that guide every interaction and transaction
              </p>
            </div>
          </SectionFade>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { title: "Integrity", desc: "We operate with complete transparency in every transaction. No hidden fees, no misleading information — just honest, professional service." },
              { title: "Excellence", desc: "From property selection to after-sales support, we pursue excellence in every detail. Only the finest properties make it into our portfolio." },
              { title: "Client-First", desc: "Your needs drive our recommendations. We listen carefully, understand deeply, and deliver solutions that genuinely serve your interests." },
              { title: "Expertise", desc: "Our team combines decades of market knowledge with continuous professional development to provide informed, insightful guidance." },
              { title: "Discretion", desc: "We understand the privacy needs of luxury clientele. All interactions and transactions are handled with the utmost confidentiality." },
              { title: "Innovation", desc: "We embrace technology and new methodologies to enhance the property search and acquisition experience for our clients." },
            ].map((value, idx) => (
              <SectionFade key={idx}>
                <div
                  className="p-8 h-full transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
                  style={{ background: "var(--light-mint)", borderRadius: 4 }}
                >
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center mb-4"
                    style={{ background: "var(--deep-teal)" }}
                  >
                    <CheckCircle size={18} className="text-white" />
                  </div>
                  <h4 className="font-display text-lg mb-2" style={{ color: "var(--deep-teal)" }}>{value.title}</h4>
                  <p className="text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>{value.desc}</p>
                </div>
              </SectionFade>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
}
