import { Link } from "react-router-dom";
import { ArrowRight, Shield, Clock, Users, FileCheck } from "lucide-react";
import { services } from "@/data/properties";
import { useScrollFade } from "@/hooks/useScrollFade";

function SectionFade({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, isVisible } = useScrollFade(0.15);
  return (
    <div ref={ref} className={`section-fade ${isVisible ? "visible" : ""} ${className}`}>
      {children}
    </div>
  );
}

export default function Services() {
  const processSteps = [
    { step: "01", title: "Initial Consultation", desc: "We begin with a thorough understanding of your requirements, budget, timeline, and preferences through a detailed consultation." },
    { step: "02", title: "Property Search", desc: "Our team curates a selection of properties matching your criteria, providing detailed information and virtual tours where available." },
    { step: "03", title: "Property Viewings", desc: "We arrange personalized visits at your convenience, accompanying you to provide insights and answer questions on-site." },
    { step: "04", title: "Negotiation & Offer", desc: "Once you find your ideal property, we handle all negotiations professionally to secure the best terms on your behalf." },
    { step: "05", title: "Legal & Documentation", desc: "Our legal partners ensure all documentation is in order, conducting due diligence and managing the transfer process." },
    { step: "06", title: "After-Sales Support", desc: "Our relationship continues beyond closing. We offer property management, renovation advice, and ongoing assistance." },
  ];

  return (
    <main className="pt-[80px]">
      {/* Hero */}
      <section className="py-16 md:py-24" style={{ background: "linear-gradient(135deg, #04395E 0%, #002845 100%)" }}>
        <div className="max-w-[1200px] mx-auto px-6 text-center">
          <SectionFade>
            <p className="text-xs uppercase tracking-[0.15em] mb-3" style={{ color: "var(--cool-mint)" }}>What We Offer</p>
            <h1 className="font-display text-3xl md:text-5xl text-white mb-4">Our Services</h1>
            <p className="text-base max-w-2xl mx-auto" style={{ color: "rgba(255,255,255,0.7)" }}>
              Comprehensive luxury real estate services tailored to meet the unique needs of discerning clients
            </p>
          </SectionFade>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {services.map((service) => (
              <SectionFade key={service.id}>
                <div
                  className="p-8 md:p-10 h-full flex flex-col transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
                  style={{ background: "var(--light-mint)", borderRadius: 4, borderLeft: "3px solid var(--deep-teal)" }}
                >
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="font-display text-xl md:text-2xl" style={{ color: "var(--deep-teal)" }}>{service.title}</h3>
                    <img src={service.icon} alt={service.title} className="w-14 h-14 object-contain flex-shrink-0 ml-4" />
                  </div>
                  <p className="text-sm leading-relaxed flex-1" style={{ color: "var(--text-secondary)" }}>{service.description}</p>
                  <Link
                    to="/consultation"
                    className="inline-flex items-center gap-2 mt-6 text-sm font-medium"
                    style={{ color: "var(--deep-teal)" }}
                  >
                    Learn More <ArrowRight size={14} />
                  </Link>
                </div>
              </SectionFade>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-20" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-14">
              <h2 className="font-display text-3xl md:text-4xl mb-4" style={{ color: "var(--deep-teal)" }}>Our Process</h2>
              <p className="text-lg max-w-2xl mx-auto" style={{ color: "var(--text-secondary)" }}>
                A transparent, step-by-step approach to finding your perfect property
              </p>
            </div>
          </SectionFade>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {processSteps.map((step, idx) => (
              <SectionFade key={idx}>
                <div className="bg-white p-8 rounded transition-all duration-300 hover:-translate-y-1 hover:shadow-lg h-full">
                  <span className="font-display text-4xl block mb-4" style={{ color: "var(--warm-sage)" }}>{step.step}</span>
                  <h4 className="font-display text-lg mb-2" style={{ color: "var(--deep-teal)" }}>{step.title}</h4>
                  <p className="text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>{step.desc}</p>
                </div>
              </SectionFade>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <SectionFade>
              <div>
                <h2 className="font-display text-3xl md:text-4xl mb-6" style={{ color: "var(--deep-teal)" }}>
                  Why Choose ASAS?
                </h2>
                <div className="space-y-5">
                  {[
                    { icon: Shield, title: "Verified Properties", desc: "Every listing is thoroughly vetted and verified by our team before being presented to clients." },
                    { icon: Users, title: "Dedicated Agent", desc: "You work with a single dedicated agent who understands your needs from start to finish." },
                    { icon: FileCheck, title: "Legal Support", desc: "Our legal partners handle all documentation, ensuring a smooth and secure transaction." },
                    { icon: Clock, title: "Ongoing Support", desc: "Our relationship continues after closing with property management and renovation assistance." },
                  ].map((item, idx) => (
                    <div key={idx} className="flex items-start gap-4">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0" style={{ background: "var(--deep-teal)" }}>
                        <item.icon size={18} className="text-white" />
                      </div>
                      <div>
                        <h4 className="font-medium mb-1" style={{ color: "var(--deep-teal)" }}>{item.title}</h4>
                        <p className="text-sm" style={{ color: "var(--text-secondary)" }}>{item.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </SectionFade>

            <SectionFade>
              <div className="relative">
                <img
                  src="/images/property-1.jpg"
                  alt="Luxury villa"
                  className="w-full rounded"
                  style={{ aspectRatio: "4/3", objectFit: "cover" }}
                />
                <div
                  className="absolute bottom-6 left-6 right-6 p-6"
                  style={{ background: "rgba(255,255,255,0.95)", backdropFilter: "blur(8px)", borderRadius: 4 }}
                >
                  <p className="text-sm font-medium mb-2" style={{ color: "var(--deep-teal)" }}>
                    Ready to get started?
                  </p>
                  <Link to="/consultation" className="btn-primary w-full">
                    Schedule a Free Consultation
                    <ArrowRight size={16} className="ml-2" />
                  </Link>
                </div>
              </div>
            </SectionFade>
          </div>
        </div>
      </section>
    </main>
  );
}
