import { useState } from "react";
import { Link } from "react-router-dom";
import { CheckCircle, Calendar, User, Mail, Phone, MessageSquare, ChevronRight, Shield, Clock, Star } from "lucide-react";
import { useScrollFade } from "@/hooks/useScrollFade";

function SectionFade({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, isVisible } = useScrollFade(0.15);
  return (
    <div ref={ref} className={`section-fade ${isVisible ? "visible" : ""} ${className}`}>
      {children}
    </div>
  );
}

export default function Consultation() {
  const [step, setStep] = useState(1);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    propertyType: "",
    budget: "",
    timeline: "",
    message: "",
  });

  const handleNext = () => {
    if (step < 3) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <main className="pt-[80px]">
      {/* Hero */}
      <section className="py-16 md:py-20" style={{ background: "linear-gradient(135deg, #04395E 0%, #002845 100%)" }}>
        <div className="max-w-[800px] mx-auto px-6 text-center">
          <SectionFade>
            <p className="text-xs uppercase tracking-[0.15em] mb-3" style={{ color: "var(--cool-mint)" }}>Free Consultation</p>
            <h1 className="font-display text-3xl md:text-4xl text-white mb-4">
              Schedule Your Property Consultation
            </h1>
            <p className="text-base" style={{ color: "rgba(255,255,255,0.7)" }}>
              Complete the form below and our expert agents will prepare a personalized property selection for you
            </p>
          </SectionFade>
        </div>
      </section>

      {/* Trust Bar */}
      <div className="py-6" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[800px] mx-auto px-6 flex flex-wrap justify-center gap-6">
          {[
            { icon: Shield, text: "100% Confidential" },
            { icon: Clock, text: "Response within 24h" },
            { icon: Star, text: "No Obligation" },
          ].map((item, idx) => (
            <div key={idx} className="flex items-center gap-2">
              <item.icon size={16} style={{ color: "var(--deep-teal)" }} />
              <span className="text-sm font-medium" style={{ color: "var(--deep-teal)" }}>{item.text}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Form */}
      <section className="py-16" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[600px] mx-auto px-6">
          {submitted ? (
            <SectionFade>
              <div className="bg-white p-10 rounded text-center">
                <CheckCircle size={56} className="mx-auto mb-5" style={{ color: "var(--soft-sage)" }} />
                <h2 className="font-display text-2xl mb-3" style={{ color: "var(--deep-teal)" }}>
                  Consultation Request Submitted
                </h2>
                <p className="text-sm mb-2" style={{ color: "var(--text-secondary)" }}>
                  Thank you, <strong>{formData.name}</strong>. We have received your consultation request.
                </p>
                <p className="text-sm mb-6" style={{ color: "var(--text-secondary)" }}>
                  One of our property consultants will contact you within 24 hours to confirm your appointment and discuss your requirements.
                </p>
                <div className="flex flex-wrap justify-center gap-3">
                  <Link to="/properties" className="btn-primary">
                    Browse Properties
                  </Link>
                  <a
                    href="https://wa.me/213550000000"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-6 py-3 text-sm font-medium transition-all duration-200 hover:opacity-90"
                    style={{ background: "linear-gradient(90deg, #25D366 0%, #128C7E 100%)", color: "white", borderRadius: 2 }}
                  >
                    Chat on WhatsApp
                  </a>
                </div>
              </div>
            </SectionFade>
          ) : (
            <SectionFade>
              <div className="bg-white p-8 rounded">
                {/* Progress */}
                <div className="flex items-center gap-2 mb-8">
                  {[1, 2, 3].map((s) => (
                    <div key={s} className="flex-1 flex items-center gap-2">
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium text-white"
                        style={{ background: s <= step ? "var(--deep-teal)" : "var(--silver-sage)" }}
                      >
                        {s < step ? <CheckCircle size={16} /> : s}
                      </div>
                      {s < 3 && <div className="flex-1 h-px" style={{ background: s < step ? "var(--deep-teal)" : "var(--silver-sage)" }} />}
                    </div>
                  ))}
                </div>

                <form onSubmit={step === 3 ? handleSubmit : (e) => { e.preventDefault(); handleNext(); }}>
                  {/* Step 1: Personal Info */}
                  {step === 1 && (
                    <div className="space-y-5">
                      <h3 className="font-display text-xl mb-1" style={{ color: "var(--deep-teal)" }}>Your Information</h3>
                      <p className="text-sm mb-4" style={{ color: "var(--text-secondary)" }}>Tell us a bit about yourself so we can serve you better.</p>

                      <div>
                        <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>
                          <User size={14} className="inline mr-1" /> Full Name *
                        </label>
                        <input type="text" required placeholder="Your full name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>
                          <Mail size={14} className="inline mr-1" /> Email Address *
                        </label>
                        <input type="email" required placeholder="your@email.com" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>
                          <Phone size={14} className="inline mr-1" /> Phone Number *
                        </label>
                        <input type="tel" required placeholder="+213 5XX XXX XXX" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} />
                      </div>
                    </div>
                  )}

                  {/* Step 2: Property Preferences */}
                  {step === 2 && (
                    <div className="space-y-5">
                      <h3 className="font-display text-xl mb-1" style={{ color: "var(--deep-teal)" }}>Property Preferences</h3>
                      <p className="text-sm mb-4" style={{ color: "var(--text-secondary)" }}>Help us understand what you are looking for.</p>

                      <div>
                        <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>Property Type</label>
                        <select value={formData.propertyType} onChange={(e) => setFormData({ ...formData, propertyType: e.target.value })}>
                          <option value="">Select property type</option>
                          <option value="villa">Villa</option>
                          <option value="apartment">Apartment</option>
                          <option value="house">House</option>
                          <option value="penthouse">Penthouse</option>
                          <option value="land">Land</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>Budget Range</label>
                        <select value={formData.budget} onChange={(e) => setFormData({ ...formData, budget: e.target.value })}>
                          <option value="">Select budget range</option>
                          <option value="50-100m">50M - 100M DZD</option>
                          <option value="100-150m">100M - 150M DZD</option>
                          <option value="150-200m">150M - 200M DZD</option>
                          <option value="200m+">200M+ DZD</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>Purchase Timeline</label>
                        <select value={formData.timeline} onChange={(e) => setFormData({ ...formData, timeline: e.target.value })}>
                          <option value="">Select timeline</option>
                          <option value="immediate">Immediate</option>
                          <option value="1-3months">1 - 3 Months</option>
                          <option value="3-6months">3 - 6 Months</option>
                          <option value="6-12months">6 - 12 Months</option>
                          <option value="just-browsing">Just Browsing</option>
                        </select>
                      </div>
                    </div>
                  )}

                  {/* Step 3: Message */}
                  {step === 3 && (
                    <div className="space-y-5">
                      <h3 className="font-display text-xl mb-1" style={{ color: "var(--deep-teal)" }}>Additional Details</h3>
                      <p className="text-sm mb-4" style={{ color: "var(--text-secondary)" }}>Anything else you would like us to know?</p>

                      <div>
                        <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>
                          <MessageSquare size={14} className="inline mr-1" /> Your Message
                        </label>
                        <textarea rows={5} placeholder="Describe your ideal property, specific requirements, or any questions..." value={formData.message} onChange={(e) => setFormData({ ...formData, message: e.target.value })} />
                      </div>

                      <div className="flex items-start gap-3 p-4 rounded" style={{ background: "var(--light-mint)" }}>
                        <Shield size={16} className="mt-0.5 flex-shrink-0" style={{ color: "var(--deep-teal)" }} />
                        <p className="text-xs" style={{ color: "var(--text-secondary)" }}>
                          Your information is kept strictly confidential and will only be used to provide you with personalized property recommendations. We never share your data with third parties.
                        </p>
                      </div>
                    </div>
                  )}

                  {/* Buttons */}
                  <div className="flex items-center justify-between mt-8">
                    {step > 1 ? (
                      <button type="button" onClick={handleBack} className="px-6 py-2.5 text-sm font-medium border transition-all duration-200" style={{ borderColor: "var(--silver-sage)", color: "var(--text-primary)", borderRadius: 2 }}>
                        Back
                      </button>
                    ) : (
                      <div />
                    )}
                    <button type="submit" className="btn-primary">
                      {step === 3 ? (
                        <>
                          <Calendar size={16} className="mr-2" />
                          Schedule Consultation
                        </>
                      ) : (
                        <>
                          Continue <ChevronRight size={16} className="ml-1" />
                        </>
                      )}
                    </button>
                  </div>
                </form>
              </div>
            </SectionFade>
          )}
        </div>
      </section>
    </main>
  );
}
