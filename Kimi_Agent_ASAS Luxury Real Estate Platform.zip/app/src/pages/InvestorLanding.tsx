import { useState } from "react";
import { Link } from "react-router-dom";
import { TrendingUp, Shield, Globe, BarChart3, CheckCircle, ArrowRight, Star, Award, Users, Phone, Mail } from "lucide-react";
import { useScrollFade } from "@/hooks/useScrollFade";

function SectionFade({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, isVisible } = useScrollFade(0.15);
  return (
    <div ref={ref} className={`section-fade ${isVisible ? "visible" : ""} ${className}`}>
      {children}
    </div>
  );
}

export default function InvestorLanding() {
  const [formData, setFormData] = useState({ name: "", email: "", phone: "", investmentRange: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <main className="pt-[80px]">
      {/* Hero */}
      <section className="relative py-20 md:py-28 overflow-hidden" style={{ background: "linear-gradient(135deg, #04395E 0%, #002845 100%)" }}>
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-40 h-40 rounded-full" style={{ background: "var(--warm-sage)" }} />
          <div className="absolute bottom-10 right-10 w-60 h-60 rounded-full" style={{ background: "var(--soft-sage)" }} />
        </div>
        <div className="max-w-[1200px] mx-auto px-6 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <SectionFade>
              <div className="flex items-center gap-2 mb-4">
                <span className="px-3 py-1 text-[11px] font-medium uppercase tracking-wider text-white" style={{ background: "rgba(255,255,255,0.15)", borderRadius: 2 }}>
                  Exclusive Investor Program
                </span>
              </div>
              <h1 className="font-display text-3xl md:text-5xl text-white mb-6 leading-tight">
                Build Your Wealth Through
                <span style={{ color: "var(--warm-sage)" }}> Algerian Real Estate</span>
              </h1>
              <p className="text-base mb-8 leading-relaxed" style={{ color: "rgba(255,255,255,0.75)" }}>
                Gain exclusive access to pre-market properties, off-market deals, and institutional-grade investment analysis. Join Algeria's most exclusive investor network.
              </p>
              <div className="flex flex-wrap gap-4">
                <a href="#apply" className="btn-secondary">
                  Apply for Access
                  <ArrowRight size={16} className="ml-2" />
                </a>
                <a
                  href="https://wa.me/213550000000"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 text-sm font-medium text-white border transition-all duration-200 hover:bg-white hover:text-[var(--deep-teal)]"
                  style={{ borderColor: "rgba(255,255,255,0.3)", borderRadius: 2 }}
                >
                  Speak to an Advisor
                </a>
              </div>

              <div className="flex flex-wrap gap-6 mt-10">
                {[
                  { value: "8-12%", label: "Avg. Annual Return" },
                  { value: "50+", label: "Exclusive Properties" },
                  { value: "98%", label: "Client Retention" },
                ].map((stat, idx) => (
                  <div key={idx}>
                    <p className="font-display text-2xl text-white">{stat.value}</p>
                    <p className="text-xs" style={{ color: "rgba(255,255,255,0.5)" }}>{stat.label}</p>
                  </div>
                ))}
              </div>
            </SectionFade>

            <SectionFade>
              <div className="relative">
                <img
                  src="/images/property-5.jpg"
                  alt="Luxury investment property"
                  className="w-full rounded"
                  style={{ aspectRatio: "4/3", objectFit: "cover" }}
                />
                <div
                  className="absolute bottom-4 left-4 right-4 p-4"
                  style={{ background: "rgba(255,255,255,0.95)", backdropFilter: "blur(8px)", borderRadius: 4 }}
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ background: "var(--deep-teal)" }}>
                      <TrendingUp size={18} className="text-white" />
                    </div>
                    <div>
                      <p className="text-sm font-medium" style={{ color: "var(--deep-teal)" }}>Portfolio Performance</p>
                      <p className="text-xs" style={{ color: "var(--text-secondary)" }}>Track record of consistent returns</p>
                    </div>
                  </div>
                </div>
              </div>
            </SectionFade>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-14">
              <h2 className="font-display text-3xl md:text-4xl mb-4" style={{ color: "var(--deep-teal)" }}>
                Investor Benefits
              </h2>
              <p className="text-lg max-w-2xl mx-auto" style={{ color: "var(--text-secondary)" }}>
                Exclusive advantages reserved for our registered investors
              </p>
            </div>
          </SectionFade>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Globe, title: "Pre-Market Access", desc: "View and reserve properties before they are listed publicly. Get first choice on the best opportunities." },
              { icon: BarChart3, title: "Investment Analysis", desc: "Receive detailed ROI projections, market comparables, and risk assessments for every opportunity." },
              { icon: Shield, title: "Legal Protection", desc: "Our legal team ensures every transaction is secure, with comprehensive due diligence and contract review." },
              { icon: Users, title: "Dedicated Advisor", desc: "A senior investment advisor manages your portfolio and identifies opportunities aligned with your strategy." },
              { icon: Award, title: "Portfolio Management", desc: "Full property management services including tenant sourcing, maintenance, and financial reporting." },
              { icon: TrendingUp, title: "Exit Strategy Planning", desc: "We help plan and execute profitable exits, whether through sale, refinancing, or portfolio restructuring." },
            ].map((benefit, idx) => (
              <SectionFade key={idx}>
                <div className="bg-white p-8 rounded transition-all duration-300 hover:-translate-y-1 hover:shadow-lg h-full">
                  <div className="w-12 h-12 rounded-full flex items-center justify-center mb-4" style={{ background: "var(--deep-teal)" }}>
                    <benefit.icon size={22} className="text-white" />
                  </div>
                  <h4 className="font-display text-lg mb-2" style={{ color: "var(--deep-teal)" }}>{benefit.title}</h4>
                  <p className="text-sm" style={{ color: "var(--text-secondary)" }}>{benefit.desc}</p>
                </div>
              </SectionFade>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-14">
              <h2 className="font-display text-3xl md:text-4xl mb-4" style={{ color: "var(--deep-teal)" }}>
                Investor Success Stories
              </h2>
              <p className="text-lg max-w-2xl mx-auto" style={{ color: "var(--text-secondary)" }}>
                Hear from investors who have built wealth through Algerian real estate with ASAS
              </p>
            </div>
          </SectionFade>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { text: "ASAS helped me build a portfolio of 5 luxury villas in Oran over 3 years. The returns have consistently exceeded projections, and their management services are exceptional.", name: "Youssef Benkhedda", role: "Serial Investor", portfolio: "5 Properties" },
              { text: "As a European investor, I needed a trustworthy partner on the ground. ASAS handled everything from property selection to tenant management. My returns have averaged 9.5% annually.", name: "Marie Dubois", role: "International Investor", portfolio: "3 Properties" },
              { text: "The pre-market access alone is worth joining the program. I secured a prime coastal property at 15% below market value. The team's market intelligence is unmatched.", name: "Karim Medelci", role: "Portfolio Investor", portfolio: "7 Properties" },
            ].map((story, idx) => (
              <SectionFade key={idx}>
                <div className="p-8 rounded h-full flex flex-col" style={{ background: "var(--light-mint)" }}>
                  <div className="flex gap-1 mb-4">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} size={14} fill="var(--warm-sage)" style={{ color: "var(--warm-sage)" }} />
                    ))}
                  </div>
                  <p className="text-sm leading-relaxed flex-1 mb-6" style={{ color: "var(--text-primary)" }}>
                    &ldquo;{story.text}&rdquo;
                  </p>
                  <div className="flex items-center justify-between pt-4" style={{ borderTop: "1px solid var(--silver-sage)" }}>
                    <div>
                      <p className="font-medium text-sm" style={{ color: "var(--deep-teal)" }}>{story.name}</p>
                      <p className="text-xs" style={{ color: "var(--taupe)" }}>{story.role}</p>
                    </div>
                    <span
                      className="px-3 py-1 text-[11px] font-medium"
                      style={{ background: "white", color: "var(--deep-teal)", borderRadius: 2 }}
                    >
                      {story.portfolio}
                    </span>
                  </div>
                </div>
              </SectionFade>
            ))}
          </div>
        </div>
      </section>

      {/* Application Form */}
      <section id="apply" className="py-20" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[800px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-10">
              <h2 className="font-display text-3xl md:text-4xl mb-4" style={{ color: "var(--deep-teal)" }}>
                Apply for Investor Access
              </h2>
              <p className="text-lg" style={{ color: "var(--text-secondary)" }}>
                Complete the application below. Our team will review and contact you within 48 hours.
              </p>
            </div>
          </SectionFade>

          <SectionFade>
            {submitted ? (
              <div className="bg-white p-10 rounded text-center">
                <CheckCircle size={56} className="mx-auto mb-5" style={{ color: "var(--soft-sage)" }} />
                <h3 className="font-display text-2xl mb-3" style={{ color: "var(--deep-teal)" }}>
                  Application Received
                </h3>
                <p className="text-sm mb-6" style={{ color: "var(--text-secondary)" }}>
                  Thank you for your interest in the ASAS Investor Program. Our investment team will review your application and contact you within 48 hours to schedule a confidential consultation.
                </p>
                <Link to="/properties" className="btn-primary">
                  Explore Properties
                </Link>
              </div>
            ) : (
              <div className="bg-white p-8 rounded">
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>Full Name *</label>
                      <input type="text" required placeholder="Your full name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>Email Address *</label>
                      <input type="email" required placeholder="your@email.com" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>Phone Number *</label>
                      <input type="tel" required placeholder="+213 5XX XXX XXX" value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>Investment Range *</label>
                      <select required value={formData.investmentRange} onChange={(e) => setFormData({ ...formData, investmentRange: e.target.value })}>
                        <option value="">Select range</option>
                        <option value="50-100m">50M - 100M DZD</option>
                        <option value="100-200m">100M - 200M DZD</option>
                        <option value="200-500m">200M - 500M DZD</option>
                        <option value="500m+">500M+ DZD</option>
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>Investment Goals</label>
                    <textarea rows={4} placeholder="Describe your investment objectives, timeline, and any specific requirements..." value={formData.message} onChange={(e) => setFormData({ ...formData, message: e.target.value })} />
                  </div>
                  <div className="flex items-start gap-3 p-4 rounded" style={{ background: "var(--light-mint)" }}>
                    <Shield size={16} className="mt-0.5 flex-shrink-0" style={{ color: "var(--deep-teal)" }} />
                    <p className="text-xs" style={{ color: "var(--text-secondary)" }}>
                      All applications are reviewed confidentially. We respect your privacy and will only use this information to assess your eligibility for the Investor Program.
                    </p>
                  </div>
                  <button type="submit" className="btn-primary w-full">
                    Submit Application
                    <ArrowRight size={16} className="ml-2" />
                  </button>
                </form>
              </div>
            )}
          </SectionFade>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16" style={{ background: "linear-gradient(90deg, #04395E 0%, #013A63 100%)" }}>
        <div className="max-w-[1200px] mx-auto px-6 text-center">
          <SectionFade>
            <h3 className="font-display text-2xl text-white mb-4">
              Questions About the Program?
            </h3>
            <p className="text-base max-w-xl mx-auto mb-6" style={{ color: "rgba(255,255,255,0.7)" }}>
              Our investment team is available to discuss your goals and explain how the program works.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <a
                href="https://wa.me/213550000000"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-medium text-white border transition-all duration-200 hover:bg-white hover:text-[var(--deep-teal)]"
                style={{ borderColor: "rgba(255,255,255,0.3)", borderRadius: 2 }}
              >
                <Phone size={16} /> WhatsApp Us
              </a>
              <a href="mailto:invest@asas-realestate.dz" className="inline-flex items-center gap-2 px-6 py-3 text-sm font-medium border transition-all duration-200 hover:bg-white hover:text-[var(--deep-teal)]" style={{ borderColor: "rgba(255,255,255,0.3)", color: "white", borderRadius: 2 }}>
                <Mail size={16} /> Email Us
              </a>
            </div>
          </SectionFade>
        </div>
      </section>
    </main>
  );
}
