import { ArrowRight, Calendar, Clock } from "lucide-react";
import { blogPosts } from "@/data/properties";
import { useScrollFade } from "@/hooks/useScrollFade";
import { useState } from "react";

function SectionFade({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, isVisible } = useScrollFade(0.15);
  return (
    <div ref={ref} className={`section-fade ${isVisible ? "visible" : ""} ${className}`}>
      {children}
    </div>
  );
}

const categories = ["All", "Market Analysis", "Location Guide", "Investment", "Architecture", "Lifestyle", "Guide"];

export default function Blog() {
  const [selectedCategory, setSelectedCategory] = useState("All");

  const filtered = selectedCategory === "All"
    ? blogPosts
    : blogPosts.filter((p) => p.category === selectedCategory);

  const featured = blogPosts[0];

  return (
    <main className="pt-[80px]">
      {/* Hero */}
      <section className="py-16 md:py-24" style={{ background: "linear-gradient(135deg, #04395E 0%, #002845 100%)" }}>
        <div className="max-w-[1200px] mx-auto px-6 text-center">
          <SectionFade>
            <p className="text-xs uppercase tracking-[0.15em] mb-3" style={{ color: "var(--cool-mint)" }}>Knowledge Hub</p>
            <h1 className="font-display text-3xl md:text-5xl text-white mb-4">Insights & Blog</h1>
            <p className="text-base max-w-2xl mx-auto" style={{ color: "rgba(255,255,255,0.7)" }}>
              Expert perspectives on Algerian luxury real estate, market trends, and investment strategies
            </p>
          </SectionFade>
        </div>
      </section>

      {/* Featured Article */}
      <section className="py-16" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div
              className="grid grid-cols-1 lg:grid-cols-2 gap-0 rounded overflow-hidden"
              style={{ background: "white" }}
            >
              <div style={{ aspectRatio: "16/10" }}>
                <img src={featured.image} alt={featured.title} className="w-full h-full object-cover" />
              </div>
              <div className="p-8 md:p-12 flex flex-col justify-center">
                <div className="flex items-center gap-4 mb-4">
                  <span
                    className="px-3 py-1 text-xs font-medium uppercase text-white"
                    style={{ background: "var(--deep-teal)", borderRadius: 2 }}
                  >
                    {featured.category}
                  </span>
                  <span className="flex items-center gap-1 text-xs" style={{ color: "var(--taupe)" }}>
                    <Calendar size={12} /> {featured.date}
                  </span>
                  <span className="flex items-center gap-1 text-xs" style={{ color: "var(--taupe)" }}>
                    <Clock size={12} /> {featured.readTime}
                  </span>
                </div>
                <h2 className="font-display text-2xl md:text-3xl mb-4" style={{ color: "var(--deep-teal)" }}>
                  {featured.title}
                </h2>
                <p className="text-base leading-relaxed mb-6" style={{ color: "var(--text-secondary)" }}>
                  {featured.excerpt}
                </p>
                <button
                  className="inline-flex items-center gap-2 text-sm font-medium self-start"
                  style={{ color: "var(--deep-teal)" }}
                >
                  Read Article <ArrowRight size={14} />
                </button>
              </div>
            </div>
          </SectionFade>
        </div>
      </section>

      {/* Category Filter */}
      <section className="pb-8" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className="px-4 py-2 text-sm transition-all duration-200"
                style={{
                  background: selectedCategory === cat ? "var(--deep-teal)" : "white",
                  color: selectedCategory === cat ? "white" : "var(--text-primary)",
                  borderRadius: 2,
                }}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Blog Grid */}
      <section className="pb-20" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filtered.map((post) => (
              <SectionFade key={post.id}>
                <div className="bg-white rounded overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-lg h-full flex flex-col">
                  <div style={{ aspectRatio: "16/10" }} className="overflow-hidden">
                    <img
                      src={post.image}
                      alt={post.title}
                      className="w-full h-full object-cover transition-transform duration-600 hover:scale-105"
                      loading="lazy"
                    />
                  </div>
                  <div className="p-6 flex-1 flex flex-col">
                    <div className="flex items-center gap-3 mb-3">
                      <span
                        className="px-2.5 py-0.5 text-[11px] font-medium uppercase"
                        style={{ background: "var(--mist)", color: "var(--deep-teal)", borderRadius: 2 }}
                      >
                        {post.category}
                      </span>
                      <span className="text-[11px]" style={{ color: "var(--taupe)" }}>
                        {post.readTime}
                      </span>
                    </div>
                    <h3 className="font-display text-lg mb-2" style={{ color: "var(--deep-teal)" }}>
                      {post.title}
                    </h3>
                    <p className="text-sm leading-relaxed flex-1" style={{ color: "var(--text-secondary)" }}>
                      {post.excerpt}
                    </p>
                    <div className="flex items-center justify-between mt-4 pt-4" style={{ borderTop: "1px solid var(--silver-sage)" }}>
                      <span className="text-xs" style={{ color: "var(--taupe)" }}>{post.date}</span>
                      <button className="inline-flex items-center gap-1 text-xs font-medium" style={{ color: "var(--deep-teal)" }}>
                        Read More <ArrowRight size={12} />
                      </button>
                    </div>
                  </div>
                </div>
              </SectionFade>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter CTA */}
      <section className="py-16" style={{ background: "linear-gradient(90deg, #04395E 0%, #013A63 100%)" }}>
        <div className="max-w-[600px] mx-auto px-6 text-center">
          <SectionFade>
            <h3 className="font-display text-2xl text-white mb-3">
              Stay Informed
            </h3>
            <p className="text-sm mb-6" style={{ color: "rgba(255,255,255,0.7)" }}>
              Subscribe to receive the latest market insights and property updates directly to your inbox.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <input
                type="email"
                placeholder="Enter your email address"
                className="flex-1 min-h-[48px] px-4 text-sm"
                style={{ borderRadius: 2, border: "none" }}
              />
              <button
                className="px-6 py-3 text-sm font-medium transition-all duration-200 hover:opacity-90"
                style={{ background: "var(--warm-sage)", color: "var(--deep-teal)", borderRadius: 2 }}
              >
                Subscribe
              </button>
            </div>
          </SectionFade>
        </div>
      </section>
    </main>
  );
}
