import { useParams, Link } from "react-router-dom";
import { MapPin, Bed, Bath, Maximize, CheckCircle, MessageCircle, Calendar } from "lucide-react";
import { properties } from "@/data/properties";
import PropertyCard from "@/components/PropertyCard";
import { useScrollFade } from "@/hooks/useScrollFade";
import { useState } from "react";

export default function PropertyDetail() {
  const { id } = useParams<{ id: string }>();
  const property = properties.find((p) => p.id === Number(id));
  const [activeImage, setActiveImage] = useState(0);
  const { ref, isVisible } = useScrollFade(0.05);
  void isVisible; // used for animation trigger

  if (!property) {
    return (
      <main className="pt-[80px] min-h-[60vh] flex items-center justify-center">
        <div className="text-center">
          <h2 className="font-display text-2xl mb-4" style={{ color: "var(--deep-teal)" }}>
            Property Not Found
          </h2>
          <Link to="/properties" className="btn-primary">
            Browse All Properties
          </Link>
        </div>
      </main>
    );
  }

  const related = properties.filter((p) => p.id !== property.id && p.type === property.type).slice(0, 3);

  return (
    <main className="pt-[80px]">
      {/* Breadcrumb */}
      <div className="py-4" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6 flex items-center gap-2 text-sm">
          <Link to="/" className="transition-colors hover:underline" style={{ color: "var(--taupe)" }}>
            Home
          </Link>
          <span style={{ color: "var(--silver-sage)" }}>/</span>
          <Link to="/properties" className="transition-colors hover:underline" style={{ color: "var(--taupe)" }}>
            Properties
          </Link>
          <span style={{ color: "var(--silver-sage)" }}>/</span>
          <span style={{ color: "var(--deep-teal)" }}>{property.title}</span>
        </div>
      </div>

      {/* Gallery */}
      <section ref={ref} className={`section-fade ${isVisible ? "visible" : ""}`}>
        <div className="relative h-[50vh] md:h-[60vh] overflow-hidden">
          <img
            src={property.gallery[activeImage]}
            alt={property.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />

          {/* Thumbnails */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex gap-2">
            {property.gallery.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setActiveImage(idx)}
                className="w-16 h-12 md:w-20 md:h-14 rounded overflow-hidden border-2 transition-all duration-200"
                style={{
                  borderColor: idx === activeImage ? "white" : "transparent",
                  opacity: idx === activeImage ? 1 : 0.7,
                }}
              >
                <img src={img} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Property Details */}
      <section className="py-12" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
            {/* Main Content */}
            <div className="lg:col-span-2">
              <div className="mb-8">
                <div className="flex flex-wrap items-center gap-3 mb-3">
                  <span
                    className="px-3 py-1 text-xs font-medium uppercase text-white"
                    style={{ background: "var(--deep-teal)", borderRadius: 2 }}
                  >
                    {property.type}
                  </span>
                  <div className="flex items-center gap-1.5 text-sm" style={{ color: "var(--taupe)" }}>
                    <MapPin size={14} />
                    {property.location}
                  </div>
                </div>

                <h1 className="font-display text-3xl md:text-4xl mb-3" style={{ color: "var(--deep-teal)" }}>
                  {property.title}
                </h1>

                <p className="text-2xl font-medium mb-6" style={{ color: "var(--deep-teal)" }}>
                  {property.price}
                </p>

                {/* Quick Stats */}
                <div className="flex flex-wrap gap-6 mb-8 p-5 rounded" style={{ background: "white" }}>
                  <div className="flex items-center gap-2">
                    <Bed size={20} style={{ color: "var(--deep-teal)" }} />
                    <div>
                      <p className="text-xs" style={{ color: "var(--taupe)" }}>Bedrooms</p>
                      <p className="font-medium" style={{ color: "var(--deep-teal)" }}>{property.bedrooms}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Bath size={20} style={{ color: "var(--deep-teal)" }} />
                    <div>
                      <p className="text-xs" style={{ color: "var(--taupe)" }}>Bathrooms</p>
                      <p className="font-medium" style={{ color: "var(--deep-teal)" }}>{property.bathrooms}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Maximize size={20} style={{ color: "var(--deep-teal)" }} />
                    <div>
                      <p className="text-xs" style={{ color: "var(--taupe)" }}>Area</p>
                      <p className="font-medium" style={{ color: "var(--deep-teal)" }}>{property.area} m²</p>
                    </div>
                  </div>
                </div>

                {/* Description */}
                <div className="mb-8">
                  <h3 className="font-display text-xl mb-3" style={{ color: "var(--deep-teal)" }}>
                    Description
                  </h3>
                  <p className="text-base leading-relaxed" style={{ color: "var(--text-primary)" }}>
                    {property.description}
                  </p>
                </div>

                {/* Features */}
                <div className="mb-8">
                  <h3 className="font-display text-xl mb-4" style={{ color: "var(--deep-teal)" }}>
                    Key Features
                  </h3>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {property.features.map((feature) => (
                      <div
                        key={feature}
                        className="flex items-center gap-2 px-4 py-3"
                        style={{ background: "white", borderRadius: 2 }}
                      >
                        <CheckCircle size={16} style={{ color: "var(--soft-sage)" }} />
                        <span className="text-sm" style={{ color: "var(--text-primary)" }}>
                          {feature}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Sidebar */}
            <div>
              {/* Agent Card */}
              <div
                className="p-6 mb-6"
                style={{ background: "white", borderRadius: 4, boxShadow: "0 2px 12px rgba(0,0,0,0.04)" }}
              >
                <h4 className="font-display text-lg mb-4" style={{ color: "var(--deep-teal)" }}>
                  Contact Agent
                </h4>
                <div className="flex items-center gap-4 mb-5">
                  <img
                    src={property.agentImage}
                    alt={property.agent}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div>
                    <p className="font-medium" style={{ color: "var(--deep-teal)" }}>
                      {property.agent}
                    </p>
                    <p className="text-xs" style={{ color: "var(--taupe)" }}>
                      Property Consultant
                    </p>
                  </div>
                </div>

                <div className="space-y-3">
                  <a
                    href={`https://wa.me/213550000000?text=I am interested in ${property.title}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 w-full py-3 text-sm font-medium text-white transition-all duration-200 hover:opacity-90"
                    style={{
                      background: "linear-gradient(90deg, #25D366 0%, #128C7E 100%)",
                      borderRadius: 2,
                    }}
                  >
                    <MessageCircle size={16} />
                    WhatsApp Inquiry
                  </a>
                  <Link
                    to="/consultation"
                    className="flex items-center justify-center gap-2 w-full py-3 text-sm font-medium transition-all duration-200"
                    style={{
                      background: "var(--deep-teal)",
                      color: "white",
                      borderRadius: 2,
                    }}
                  >
                    <Calendar size={16} />
                    Schedule Visit
                  </Link>
                </div>
              </div>

              {/* Investment Info */}
              <div
                className="p-6"
                style={{ background: "white", borderRadius: 4, boxShadow: "0 2px 12px rgba(0,0,0,0.04)" }}
              >
                <h4 className="font-display text-lg mb-4" style={{ color: "var(--deep-teal)" }}>
                  Investment Highlights
                </h4>
                <ul className="space-y-3">
                  {[
                    "Prime location with high appreciation potential",
                    "Strong rental demand in the area",
                    "Proximity to beaches and amenities",
                    "Excellent infrastructure development",
                  ].map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm" style={{ color: "var(--text-secondary)" }}>
                      <CheckCircle size={14} className="mt-0.5 flex-shrink-0" style={{ color: "var(--soft-sage)" }} />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Related Properties */}
          {related.length > 0 && (
            <div className="mt-16">
              <h3 className="font-display text-2xl mb-8" style={{ color: "var(--deep-teal)" }}>
                Similar Properties
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {related.map((p) => (
                  <PropertyCard key={p.id} property={p} />
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}
