import { useState } from "react";
import { Search, SlidersHorizontal } from "lucide-react";
import { properties } from "@/data/properties";
import PropertyCard from "@/components/PropertyCard";
import { useScrollFade } from "@/hooks/useScrollFade";

const propertyTypes = ["All", "Villa", "Apartment", "House"];
const locations = ["All", "Oran", "Algiers"];
const priceRanges = [
  { label: "All Prices", min: 0, max: Infinity },
  { label: "Under 60M DZD", min: 0, max: 60000000 },
  { label: "60M - 100M DZD", min: 60000000, max: 100000000 },
  { label: "100M - 150M DZD", min: 100000000, max: 150000000 },
  { label: "150M+ DZD", min: 150000000, max: Infinity },
];

export default function Properties() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState("All");
  const [selectedLocation, setSelectedLocation] = useState("All");
  const [selectedPriceRange, setSelectedPriceRange] = useState(0);
  const [showFilters, setShowFilters] = useState(false);

  const { ref, isVisible } = useScrollFade(0.05);

  const filtered = properties.filter((p) => {
    if (selectedType !== "All" && p.type !== selectedType) return false;
    if (selectedLocation !== "All" && !p.location.includes(selectedLocation)) return false;
    const range = priceRanges[selectedPriceRange];
    if (p.priceValue < range.min || p.priceValue > range.max) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      return (
        p.title.toLowerCase().includes(q) ||
        p.location.toLowerCase().includes(q) ||
        p.type.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <main className="pt-[80px]">
      {/* Page Header */}
      <section
        className="py-16 md:py-20"
        style={{ background: "linear-gradient(135deg, #04395E 0%, #002845 100%)" }}
      >
        <div className="max-w-[1200px] mx-auto px-6 text-center">
          <div ref={ref} className={`section-fade ${isVisible ? "visible" : ""}`}>
            <p className="text-xs uppercase tracking-[0.15em] mb-3" style={{ color: "var(--cool-mint)" }}>
              Our Portfolio
            </p>
            <h1 className="font-display text-3xl md:text-5xl text-white mb-4">
              Properties
            </h1>
            <p className="text-base max-w-xl mx-auto" style={{ color: "rgba(255,255,255,0.7)" }}>
              Explore our curated collection of luxury villas, apartments, and houses across Algeria
            </p>
          </div>
        </div>
      </section>

      {/* Filters & Grid */}
      <section className="py-12" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          {/* Search & Filter Toggle */}
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Search
                size={18}
                className="absolute left-4 top-1/2 -translate-y-1/2"
                style={{ color: "var(--taupe)" }}
              />
              <input
                type="text"
                placeholder="Search by name, location, or type..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-11"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 px-5 py-3 text-sm font-medium border transition-all duration-200 hover:shadow-md"
              style={{
                borderColor: "var(--silver-sage)",
                color: "var(--deep-teal)",
                borderRadius: 2,
                background: "white",
              }}
            >
              <SlidersHorizontal size={16} />
              Filters
            </button>
          </div>

          {/* Filter Panel */}
          {showFilters && (
            <div
              className="p-6 mb-8 grid grid-cols-1 sm:grid-cols-3 gap-6"
              style={{ background: "white", borderRadius: 4 }}
            >
              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: "var(--deep-teal)" }}>
                  Property Type
                </label>
                <div className="flex flex-wrap gap-2">
                  {propertyTypes.map((type) => (
                    <button
                      key={type}
                      onClick={() => setSelectedType(type)}
                      className="px-3 py-1.5 text-sm transition-all duration-200"
                      style={{
                        background: selectedType === type ? "var(--deep-teal)" : "var(--mist)",
                        color: selectedType === type ? "white" : "var(--text-primary)",
                        borderRadius: 2,
                      }}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: "var(--deep-teal)" }}>
                  Location
                </label>
                <div className="flex flex-wrap gap-2">
                  {locations.map((loc) => (
                    <button
                      key={loc}
                      onClick={() => setSelectedLocation(loc)}
                      className="px-3 py-1.5 text-sm transition-all duration-200"
                      style={{
                        background: selectedLocation === loc ? "var(--deep-teal)" : "var(--mist)",
                        color: selectedLocation === loc ? "white" : "var(--text-primary)",
                        borderRadius: 2,
                      }}
                    >
                      {loc}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2" style={{ color: "var(--deep-teal)" }}>
                  Price Range
                </label>
                <select
                  value={selectedPriceRange}
                  onChange={(e) => setSelectedPriceRange(Number(e.target.value))}
                >
                  {priceRanges.map((range, idx) => (
                    <option key={idx} value={idx}>
                      {range.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* Results Count */}
          <p className="text-sm mb-6" style={{ color: "var(--text-secondary)" }}>
            Showing <strong>{filtered.length}</strong> of {properties.length} properties
          </p>

          {/* Property Grid */}
          {filtered.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filtered.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16">
              <p className="text-lg mb-2" style={{ color: "var(--deep-teal)" }}>
                No properties found
              </p>
              <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
                Try adjusting your search criteria or filters
              </p>
            </div>
          )}
        </div>
      </section>
    </main>
  );
}
