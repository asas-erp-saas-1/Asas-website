import { useState } from "react";
import { Link } from "react-router-dom";
import { MapPin, Phone, Mail, Clock, Calendar, Send, CheckCircle, MessageCircle, ArrowRight } from "lucide-react";
import { agents } from "@/data/properties";
import { useScrollFade } from "@/hooks/useScrollFade";

function SectionFade({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, isVisible } = useScrollFade(0.15);
  return (
    <div ref={ref} className={`section-fade ${isVisible ? "visible" : ""} ${className}`}>
      {children}
    </div>
  );
}

export default function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <main className="pt-[80px]">
      {/* Hero */}
      <section className="py-16 md:py-24" style={{ background: "linear-gradient(135deg, #04395E 0%, #002845 100%)" }}>
        <div className="max-w-[1200px] mx-auto px-6 text-center">
          <SectionFade>
            <p className="text-xs uppercase tracking-[0.15em] mb-3" style={{ color: "var(--cool-mint)" }}>Get in Touch</p>
            <h1 className="font-display text-3xl md:text-5xl text-white mb-4">Contact Us</h1>
            <p className="text-base max-w-2xl mx-auto" style={{ color: "rgba(255,255,255,0.7)" }}>
              We are here to answer your questions and guide you through your property journey
            </p>
          </SectionFade>
        </div>
      </section>

      {/* Contact Info Cards */}
      <section className="py-16" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 -mt-28 relative z-10">
            {[
              { icon: MapPin, title: "Visit Us", lines: ["123 Boulevard Mohamed VI", "Oran, Algeria 31000"] },
              { icon: Phone, title: "Call Us", lines: ["+213 (0)5 50 00 00 00", "+213 (0)5 50 00 00 01"] },
              { icon: Mail, title: "Email Us", lines: ["contact@asas-realestate.dz", "info@asas-realestate.dz"] },
              { icon: Clock, title: "Office Hours", lines: ["Sun - Thu: 9:00 - 18:00", "Sat: 10:00 - 14:00"] },
            ].map((item, idx) => (
              <SectionFade key={idx}>
                <div className="bg-white p-6 rounded text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-lg h-full">
                  <div className="w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4" style={{ background: "var(--deep-teal)" }}>
                    <item.icon size={20} className="text-white" />
                  </div>
                  <h4 className="font-display text-lg mb-2" style={{ color: "var(--deep-teal)" }}>{item.title}</h4>
                  {item.lines.map((line, i) => (
                    <p key={i} className="text-sm" style={{ color: "var(--text-secondary)" }}>{line}</p>
                  ))}
                </div>
              </SectionFade>
            ))}
          </div>
        </div>
      </section>

      {/* Form & Agents */}
      <section className="py-12 bg-white">
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Form */}
            <div className="lg:col-span-2">
              <SectionFade>
                <h2 className="font-display text-2xl md:text-3xl mb-2" style={{ color: "var(--deep-teal)" }}>
                  Send Us a Message
                </h2>
                <p className="text-sm mb-8" style={{ color: "var(--text-secondary)" }}>
                  Fill out the form below and we will respond within 24 hours
                </p>

                {submitted ? (
                  <div
                    className="p-8 rounded text-center"
                    style={{ background: "var(--light-mint)" }}
                  >
                    <CheckCircle size={48} className="mx-auto mb-4" style={{ color: "var(--soft-sage)" }} />
                    <h3 className="font-display text-xl mb-2" style={{ color: "var(--deep-teal)" }}>
                      Message Sent Successfully
                    </h3>
                    <p className="text-sm mb-6" style={{ color: "var(--text-secondary)" }}>
                      Thank you for contacting us. One of our representatives will get back to you within 24 hours.
                    </p>
                    <button
                      onClick={() => {
                        setSubmitted(false);
                        setFormData({ name: "", email: "", phone: "", subject: "", message: "" });
                      }}
                      className="text-sm font-medium underline"
                      style={{ color: "var(--deep-teal)" }}
                    >
                      Send Another Message
                    </button>
                  </div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-5">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>
                          Full Name *
                        </label>
                        <input
                          type="text"
                          required
                          placeholder="Your full name"
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>
                          Email Address *
                        </label>
                        <input
                          type="email"
                          required
                          placeholder="your@email.com"
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>
                          Phone Number
                        </label>
                        <input
                          type="tel"
                          placeholder="+213 5XX XXX XXX"
                          value={formData.phone}
                          onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>
                          Subject *
                        </label>
                        <select
                          required
                          value={formData.subject}
                          onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        >
                          <option value="">Select a subject</option>
                          <option value="property-inquiry">Property Inquiry</option>
                          <option value="valuation">Property Valuation</option>
                          <option value="investment">Investment Advisory</option>
                          <option value="partnership">Partnership</option>
                          <option value="general">General Question</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-1.5" style={{ color: "var(--deep-teal)" }}>
                        Message *
                      </label>
                      <textarea
                        required
                        rows={5}
                        placeholder="Tell us how we can help you..."
                        value={formData.message}
                        onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                        style={{ minHeight: 120 }}
                      />
                    </div>
                    <button type="submit" className="btn-primary">
                      <Send size={16} className="mr-2" />
                      Send Message
                    </button>
                  </form>
                )}
              </SectionFade>
            </div>

            {/* Quick Contact & Agents */}
            <div>
              <SectionFade>
                <div className="p-6 mb-6" style={{ background: "var(--light-mint)", borderRadius: 4 }}>
                  <h3 className="font-display text-lg mb-4" style={{ color: "var(--deep-teal)" }}>
                    Quick Contact
                  </h3>
                  <a
                    href="https://wa.me/213550000000"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center justify-center gap-2 w-full py-3 text-sm font-medium text-white mb-3 transition-all duration-200 hover:opacity-90"
                    style={{ background: "linear-gradient(90deg, #25D366 0%, #128C7E 100%)", borderRadius: 2 }}
                  >
                    <MessageCircle size={16} />
                    Chat on WhatsApp
                  </a>
                  <Link
                    to="/consultation"
                    className="flex items-center justify-center gap-2 w-full py-3 text-sm font-medium transition-all duration-200"
                    style={{ background: "var(--deep-teal)", color: "white", borderRadius: 2 }}
                  >
                    <Calendar size={16} />
                    Book Consultation
                  </Link>
                </div>
              </SectionFade>

              <SectionFade>
                <h3 className="font-display text-lg mb-4" style={{ color: "var(--deep-teal)" }}>
                  Our Agents
                </h3>
                <div className="space-y-4">
                  {agents.slice(0, 3).map((agent) => (
                    <div key={agent.id} className="flex items-center gap-4 p-4 rounded transition-all duration-200 hover:shadow-md" style={{ background: "var(--light-mint)" }}>
                      <img src={agent.image} alt={agent.name} className="w-14 h-14 rounded-full object-cover flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate" style={{ color: "var(--deep-teal)" }}>{agent.name}</p>
                        <p className="text-xs truncate" style={{ color: "var(--taupe)" }}>{agent.role}</p>
                      </div>
                      <a href={`tel:${agent.phone}`} className="p-2 rounded-full flex-shrink-0" style={{ background: "var(--deep-teal)" }}>
                        <Phone size={14} className="text-white" />
                      </a>
                    </div>
                  ))}
                </div>
              </SectionFade>
            </div>
          </div>
        </div>
      </section>

      {/* Map Placeholder */}
      <section className="py-12" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div
              className="relative rounded overflow-hidden"
              style={{ height: 400, background: "linear-gradient(135deg, #04395E 0%, #002845 100%)" }}
            >
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <MapPin size={48} className="mx-auto mb-4 text-white opacity-40" />
                  <p className="text-white text-lg font-display mb-1">ASAS Real Estate Office</p>
                  <p className="text-sm" style={{ color: "rgba(255,255,255,0.6)" }}>
                    123 Boulevard Mohamed VI, Oran, Algeria
                  </p>
                  <a
                    href="https://maps.google.com/?q=Oran+Algeria"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 mt-4 px-5 py-2 text-sm font-medium text-white border transition-all duration-200 hover:bg-white hover:text-[var(--deep-teal)]"
                    style={{ borderColor: "rgba(255,255,255,0.3)", borderRadius: 2 }}
                  >
                    Open in Google Maps <ArrowRight size={14} />
                  </a>
                </div>
              </div>
            </div>
          </SectionFade>
        </div>
      </section>
    </main>
  );
}
