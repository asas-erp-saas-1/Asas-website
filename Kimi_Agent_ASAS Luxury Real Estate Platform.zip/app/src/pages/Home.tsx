import { Link } from "react-router-dom";
import { ArrowRight, ChevronDown, Star, CheckCircle } from "lucide-react";
import { properties, agents, services } from "@/data/properties";
import PropertyCard from "@/components/PropertyCard";
import RotatingLetters from "@/components/RotatingLetters";
import GlassCubeOrb from "@/components/GlassCubeOrb";
import TrustBar from "@/components/TrustBar";
import { useScrollFade } from "@/hooks/useScrollFade";
import { useCountUp } from "@/hooks/useCountUp";

function SectionFade({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  const { ref, isVisible } = useScrollFade(0.15);
  return (
    <div ref={ref} className={`section-fade ${isVisible ? "visible" : ""} ${className}`}>
      {children}
    </div>
  );
}

function StatCounter({ end, suffix, label }: { end: number; suffix: string; label: string }) {
  const { count, ref } = useCountUp(end, 2000);
  return (
    <div ref={ref} className="text-center">
      <div className="font-display text-4xl md:text-[42px]" style={{ color: "var(--deep-teal)" }}>
        {count}
        {suffix}
      </div>
      <p className="text-sm mt-1" style={{ color: "var(--text-secondary)" }}>
        {label}
      </p>
    </div>
  );
}

export default function Home() {
  // featured properties available via filter
  // const featuredProperties = properties.filter((p) => p.featured);

  const scrollToProperties = () => {
    document.getElementById("properties")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <main>
      {/* ===== HERO SECTION ===== */}
      <section className="relative min-h-[100dvh] overflow-hidden flex items-center">
        {/* Background Image */}
        <div
          className="absolute inset-0 w-full h-full"
          style={{
            clipPath: "polygon(0 0, 65% 0, 55% 100%, 0 100%)",
          }}
        >
          <img
            src="/images/hero-villa.jpg"
            alt="Luxury Mediterranean villa"
            className="w-full h-full object-cover"
          />
          <div
            className="absolute inset-0"
            style={{
              background: "linear-gradient(180deg, rgba(4,57,94,0.2) 0%, rgba(0,40,69,0.5) 100%)",
            }}
          />
        </div>

        {/* Teal Panel */}
        <div
          className="absolute inset-0"
          style={{
            background: "linear-gradient(180deg, rgba(4,57,94,0.85) 0%, rgba(0,40,69,0.9) 100%)",
            clipPath: "polygon(55% 0, 100% 0, 100% 100%, 50% 100%)",
          }}
        />

        {/* Content */}
        <div className="relative z-10 max-w-[1200px] mx-auto px-6 w-full grid grid-cols-1 md:grid-cols-2 gap-8 items-center pt-20">
          {/* Left side - hero text */}
          <div className="text-white">
            <p
              className="text-xs uppercase tracking-[0.15em] mb-4 opacity-70"
              style={{ color: "var(--cool-mint)" }}
            >
              Premium Real Estate Agency
            </p>
            <h1 className="font-display text-4xl md:text-5xl lg:text-6xl leading-[1.1] mb-6">
              Discover Your
              <br />
              <span style={{ color: "var(--warm-sage)" }}>Dream Property</span>
              <br />
              in Algeria
            </h1>
            <p className="text-base md:text-lg leading-relaxed mb-8 max-w-md opacity-85">
              From coastal villas to urban penthouses, we curate the finest
              selection of luxury properties across Oran, Algiers, and beyond.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/properties" className="btn-primary">
                Browse Properties
                <ArrowRight size={18} className="ml-2" />
              </Link>
              <Link
                to="/consultation"
                className="inline-flex items-center justify-center px-8 py-3 text-base font-medium transition-all duration-300 border-2 hover:bg-white hover:text-[var(--deep-teal)]"
                style={{
                  borderColor: "rgba(255,255,255,0.4)",
                  color: "white",
                  borderRadius: 2,
                }}
              >
                Book Consultation
              </Link>
            </div>
          </div>

          {/* Right side - rotating letters */}
          <div className="hidden md:flex flex-col items-center justify-center">
            <div className="w-full max-w-[400px]">
              <RotatingLetters />
            </div>
            <p
              className="text-[13px] font-medium tracking-[0.15em] uppercase mt-4"
              style={{ color: "var(--cool-mint)" }}
            >
              Algiers, Algeria
            </p>
            <p className="text-base font-light mt-3 opacity-70 max-w-xs text-center">
              Luxury properties, exceptional homes
            </p>
          </div>
        </div>

        {/* Skip Intro */}
        <button
          onClick={scrollToProperties}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex items-center gap-2 px-5 py-2.5 text-sm font-medium text-white rounded-full transition-all duration-300 hover:scale-105"
          style={{
            background: "rgba(255,255,255,0.15)",
            backdropFilter: "blur(8px)",
          }}
        >
          Skip Intro
          <ChevronDown size={16} />
        </button>
      </section>

      {/* ===== TRUST BAR ===== */}
      <TrustBar />

      {/* ===== PROPERTIES SECTION ===== */}
      <section
        id="properties"
        className="py-24"
        style={{ background: "var(--light-mint)" }}
      >
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-14">
              <h2
                className="font-display text-3xl md:text-4xl mb-4"
                style={{ color: "var(--deep-teal)" }}
              >
                Latest Properties
              </h2>
              <p className="text-lg max-w-2xl mx-auto" style={{ color: "var(--text-secondary)" }}>
                Discover our exclusive selection of premium properties across Algeria
              </p>
            </div>
          </SectionFade>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {properties.map((property) => (
              <SectionFade key={property.id}>
                <PropertyCard property={property} />
              </SectionFade>
            ))}
          </div>

          <SectionFade className="text-center mt-12">
            <Link to="/properties" className="btn-primary inline-flex">
              View All Properties
              <ArrowRight size={18} className="ml-2" />
            </Link>
          </SectionFade>
        </div>
      </section>

      {/* ===== SERVICES SECTION ===== */}
      <section className="py-24 bg-white">
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-14">
              <h2
                className="font-display text-3xl md:text-4xl mb-4"
                style={{ color: "var(--deep-teal)" }}
              >
                Our Services
              </h2>
              <p
                className="text-lg max-w-2xl mx-auto"
                style={{ color: "var(--text-secondary)" }}
              >
                From property valuation to personalized visits, we provide a complete
                luxury real estate experience
              </p>
            </div>
          </SectionFade>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {services.map((service) => (
              <SectionFade key={service.id}>
                <div
                  className="p-8 md:p-10 transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
                  style={{
                    background: "var(--mist)",
                    borderRadius: 4,
                    borderLeft: "3px solid var(--deep-teal)",
                  }}
                >
                  <div className="flex items-start justify-between mb-4">
                    <h4
                      className="font-display text-xl md:text-2xl"
                      style={{ color: "var(--deep-teal)" }}
                    >
                      {service.title}
                    </h4>
                    <img
                      src={service.icon}
                      alt={service.title}
                      className="w-12 h-12 object-contain flex-shrink-0 ml-4"
                    />
                  </div>
                  <p className="text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                    {service.description}
                  </p>
                </div>
              </SectionFade>
            ))}
          </div>
        </div>
      </section>

      {/* ===== AGENTS SECTION ===== */}
      <section
        className="py-24"
        style={{
          background: "linear-gradient(135deg, #04395E 0%, #002845 100%)",
        }}
      >
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-14">
              <h2 className="font-display text-3xl md:text-4xl text-white mb-4">
                Our Agents
              </h2>
              <p className="text-lg max-w-2xl mx-auto" style={{ color: "rgba(255,255,255,0.7)" }}>
                Our experienced team is here to guide you every step of the way
              </p>
            </div>
          </SectionFade>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {agents.map((agent) => (
              <SectionFade key={agent.id}>
                <div
                  className="glass-card p-8 text-center transition-all duration-300 hover:-translate-y-1"
                  style={{ background: "rgba(255,255,255,0.08)" }}
                >
                  <div
                    className="w-[120px] h-[120px] mx-auto mb-5 rounded-full overflow-hidden"
                    style={{ border: "3px solid rgba(255,255,255,0.2)" }}
                  >
                    <img
                      src={agent.image}
                      alt={agent.name}
                      className="w-full h-full object-cover"
                      loading="lazy"
                    />
                  </div>
                  <h4 className="text-lg font-medium text-white mb-1">
                    {agent.name}
                  </h4>
                  <p
                    className="text-sm mb-4"
                    style={{ color: "rgba(255,255,255,0.6)" }}
                  >
                    {agent.role}
                  </p>
                  <Link
                    to="/about"
                    className="text-sm transition-colors duration-200 hover:text-white"
                    style={{ color: "var(--warm-sage)" }}
                  >
                    View Profile
                  </Link>
                </div>
              </SectionFade>
            ))}
          </div>
        </div>
      </section>

      {/* ===== ABOUT SECTION ===== */}
      <section className="py-24" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-16">
            <SectionFade>
              <div className="rounded overflow-hidden" style={{ aspectRatio: "3/2" }}>
                <img
                  src="/images/about-cityscape.jpg"
                  alt="Oran coastal cityscape"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
              </div>
            </SectionFade>

            <SectionFade>
              <div>
                <h2
                  className="font-display text-3xl md:text-4xl mb-6"
                  style={{ color: "var(--deep-teal)" }}
                >
                  About Us
                </h2>
                <p className="text-base leading-relaxed mb-4" style={{ color: "var(--text-primary)" }}>
                  Founded in 2011, <strong style={{ color: "var(--deep-teal)" }}>ASAS Real Estate</strong> has established
                  itself as Algeria's premier luxury property agency. With offices in Oran and Algiers,
                  we specialize in connecting discerning clients with exceptional properties across
                  the Mediterranean coast.
                </p>
                <p className="text-base leading-relaxed mb-4" style={{ color: "var(--text-primary)" }}>
                  Our team of seasoned professionals brings together deep local market knowledge,
                  international best practices, and an unwavering commitment to client satisfaction.
                  We understand that acquiring a luxury property is not merely a transaction — it is
                  the realization of a vision.
                </p>
                <p className="text-base leading-relaxed mb-6" style={{ color: "var(--text-primary)" }}>
                  Every property in our portfolio undergoes rigorous quality assessment. Every client
                  receives personalized attention from initial consultation through to final signature.
                  This meticulous approach has earned us the trust of over 500 satisfied clients and
                  a reputation for excellence that continues to grow.
                </p>

                <div className="flex flex-wrap gap-3">
                  {[
                    "Premium Portfolio",
                    "Expert Guidance",
                    "Full Legal Support",
                    "After-Sales Care",
                  ].map((item) => (
                    <span
                      key={item}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-sm"
                      style={{
                        background: "var(--mist)",
                        color: "var(--deep-teal)",
                        borderRadius: 2,
                      }}
                    >
                      <CheckCircle size={14} />
                      {item}
                    </span>
                  ))}
                </div>
              </div>
            </SectionFade>
          </div>

          {/* Stats */}
          <SectionFade>
            <div
              className="grid grid-cols-2 md:grid-cols-4 gap-8 py-10 px-6 md:px-12 rounded"
              style={{ background: "white" }}
            >
              <StatCounter end={127} suffix="+" label="Properties Sold" />
              <StatCounter end={15} suffix="+" label="Years Experience" />
              <StatCounter end={98} suffix="%" label="Client Satisfaction" />
              <StatCounter end={24} suffix="/7" label="Support Available" />
            </div>
          </SectionFade>
        </div>
      </section>

      {/* ===== CUBE ORB SECTION ===== */}
      <section className="py-24 bg-white relative overflow-hidden">
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-12">
              <h2
                className="font-display text-3xl md:text-4xl mb-4"
                style={{ color: "var(--deep-teal)" }}
              >
                Clarity in Every Detail
              </h2>
              <p
                className="text-lg max-w-2xl mx-auto"
                style={{ color: "var(--text-secondary)" }}
              >
                Just as our 3D visualization reveals the precision of every angle,
                we bring the same level of transparency and meticulous attention to
                every property in our portfolio
              </p>
            </div>
          </SectionFade>

          <GlassCubeOrb />
        </div>
      </section>

      {/* ===== TESTIMONIALS SECTION ===== */}
      <section className="py-24" style={{ background: "var(--light-mint)" }}>
        <div className="max-w-[1200px] mx-auto px-6">
          <SectionFade>
            <div className="text-center mb-14">
              <h2
                className="font-display text-3xl md:text-4xl mb-4"
                style={{ color: "var(--deep-teal)" }}
              >
                What Our Clients Say
              </h2>
              <p className="text-lg max-w-2xl mx-auto" style={{ color: "var(--text-secondary)" }}>
                Trusted by hundreds of satisfied clients across Algeria and beyond
              </p>
            </div>
          </SectionFade>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                text: "ASAS made the entire process seamless. From the first viewing to the final signing, their professionalism and attention to detail exceeded all expectations. They found us our dream villa in Oran.",
                name: "Ahmed Benali",
                role: "Property Buyer",
                rating: 5,
              },
              {
                text: "As an overseas investor, I needed an agency I could trust completely. ASAS provided transparent valuations, handled all legal complexities, and delivered exceptional returns on my investment.",
                name: "Sophie Moreau",
                role: "International Investor",
                rating: 5,
              },
              {
                text: "The team's knowledge of the luxury market is unmatched. They understood exactly what we were looking for and presented properties that perfectly matched our criteria. Truly a first-class experience.",
                name: "Karim Hadj",
                role: "Property Buyer",
                rating: 5,
              },
            ].map((testimonial, idx) => (
              <SectionFade key={idx}>
                <div
                  className="p-8 h-full flex flex-col"
                  style={{
                    background: "white",
                    borderRadius: 4,
                    boxShadow: "0 2px 12px rgba(0,0,0,0.04)",
                  }}
                >
                  <div className="flex gap-1 mb-4">
                    {Array.from({ length: testimonial.rating }).map((_, i) => (
                      <Star
                        key={i}
                        size={16}
                        fill="var(--warm-sage)"
                        style={{ color: "var(--warm-sage)" }}
                      />
                    ))}
                  </div>
                  <p className="text-sm leading-relaxed flex-1 mb-6" style={{ color: "var(--text-primary)" }}>
                    &ldquo;{testimonial.text}&rdquo;
                  </p>
                  <div>
                    <p className="font-medium text-sm" style={{ color: "var(--deep-teal)" }}>
                      {testimonial.name}
                    </p>
                    <p className="text-xs" style={{ color: "var(--taupe)" }}>
                      {testimonial.role}
                    </p>
                  </div>
                </div>
              </SectionFade>
            ))}
          </div>
        </div>
      </section>

      {/* ===== CONTACT CTA SECTION ===== */}
      <section
        className="py-20"
        style={{ background: "linear-gradient(90deg, #04395E 0%, #013A63 100%)" }}
      >
        <div className="max-w-[1200px] mx-auto px-6 text-center">
          <SectionFade>
            <h3 className="font-display text-2xl md:text-3xl text-white mb-4">
              Ready to Find Your Dream Property?
            </h3>
            <p
              className="text-base max-w-xl mx-auto mb-8"
              style={{ color: "rgba(255,255,255,0.85)" }}
            >
              Contact us today for a personalized consultation with one of our
              expert agents.
            </p>
            <Link to="/consultation" className="btn-secondary">
              Schedule a Visit
            </Link>
            <p className="mt-5 text-sm" style={{ color: "rgba(255,255,255,0.6)" }}>
              Or call us:{" "}
              <a
                href="tel:+213550000000"
                className="underline hover:text-white transition-colors"
                style={{ color: "rgba(255,255,255,0.7)" }}
              >
                +213 (0)5 50 00 00 00
              </a>
            </p>
          </SectionFade>
        </div>
      </section>
    </main>
  );
}
