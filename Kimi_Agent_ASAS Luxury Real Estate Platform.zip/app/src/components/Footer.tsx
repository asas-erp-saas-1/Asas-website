import { Link } from "react-router-dom";
import { Facebook, Instagram, Linkedin, Twitter, MapPin, Phone, Mail } from "lucide-react";

const quickLinks = [
  { label: "Home", path: "/" },
  { label: "Properties", path: "/properties" },
  { label: "Services", path: "/services" },
  { label: "Agents", path: "/about" },
  { label: "About", path: "/about" },
];

const propertyLinks = [
  { label: "Villa Oran", path: "/properties/1" },
  { label: "Appartement Oran", path: "/properties/2" },
  { label: "Oran Luxe", path: "/properties/3" },
  { label: "Villa Alger", path: "/properties/4" },
];

const socialIcons = [
  { Icon: Facebook, label: "Facebook" },
  { Icon: Instagram, label: "Instagram" },
  { Icon: Linkedin, label: "LinkedIn" },
  { Icon: Twitter, label: "Twitter" },
];

export default function Footer() {
  return (
    <footer style={{ background: "var(--forest-teal)" }}>
      <div className="max-w-[1200px] mx-auto px-6 pt-16 pb-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">
          {/* Column 1: Brand */}
          <div>
            <Link to="/" className="inline-block mb-4">
              <span className="font-display text-[22px] text-white font-semibold">
                ASAS
              </span>
              <span
                className="block text-[11px] font-light tracking-[0.1em] mt-0.5"
                style={{ color: "rgba(255,255,255,0.5)" }}
              >
                Real Estate
              </span>
            </Link>
            <p
              className="text-sm leading-relaxed"
              style={{ color: "rgba(255,255,255,0.6)" }}
            >
              Algeria's premier luxury real estate agency, connecting discerning
              clients with exceptional properties across Oran, Algiers, and
              beyond since 2011.
            </p>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h4
              className="text-sm uppercase tracking-[0.1em] mb-4"
              style={{ color: "rgba(255,255,255,0.4)" }}
            >
              Quick Links
            </h4>
            <ul className="space-y-2.5">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.path}
                    className="text-sm transition-colors duration-200 hover:text-white"
                    style={{ color: "rgba(255,255,255,0.7)" }}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Properties */}
          <div>
            <h4
              className="text-sm uppercase tracking-[0.1em] mb-4"
              style={{ color: "rgba(255,255,255,0.4)" }}
            >
              Properties
            </h4>
            <ul className="space-y-2.5">
              {propertyLinks.map((link) => (
                <li key={link.label}>
                  <Link
                    to={link.path}
                    className="text-sm transition-colors duration-200 hover:text-white"
                    style={{ color: "rgba(255,255,255,0.7)" }}
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Contact */}
          <div>
            <h4
              className="text-sm uppercase tracking-[0.1em] mb-4"
              style={{ color: "rgba(255,255,255,0.4)" }}
            >
              Contact
            </h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-2.5">
                <MapPin
                  size={16}
                  className="mt-0.5 flex-shrink-0"
                  style={{ color: "rgba(255,255,255,0.5)" }}
                />
                <span
                  className="text-sm"
                  style={{ color: "rgba(255,255,255,0.7)" }}
                >
                  123 Boulevard Mohamed VI, Oran, Algeria
                </span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone
                  size={16}
                  className="flex-shrink-0"
                  style={{ color: "rgba(255,255,255,0.5)" }}
                />
                <a
                  href="tel:+213550000000"
                  className="text-sm transition-colors duration-200 hover:text-white"
                  style={{ color: "rgba(255,255,255,0.7)" }}
                >
                  +213 (0)5 50 00 00 00
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail
                  size={16}
                  className="flex-shrink-0"
                  style={{ color: "rgba(255,255,255,0.5)" }}
                />
                <a
                  href="mailto:contact@asas-realestate.dz"
                  className="text-sm transition-colors duration-200 hover:text-white"
                  style={{ color: "rgba(255,255,255,0.7)" }}
                >
                  contact@asas-realestate.dz
                </a>
              </li>
            </ul>

            {/* Social Icons */}
            <div className="flex items-center gap-4 mt-5">
              {socialIcons.map(({ Icon, label }) => (
                <a
                  key={label}
                  href="#"
                  aria-label={label}
                  className="transition-opacity duration-200 hover:opacity-100"
                  style={{ color: "rgba(255,255,255,0.5)" }}
                  onMouseEnter={(e) =>
                    (e.currentTarget.style.color = "rgba(255,255,255,1)")
                  }
                  onMouseLeave={(e) =>
                    (e.currentTarget.style.color = "rgba(255,255,255,0.5)")
                  }
                >
                  <Icon size={20} />
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div
          className="mt-12 pt-6 flex flex-col sm:flex-row items-center justify-between gap-4"
          style={{ borderTop: "1px solid rgba(255,255,255,0.1)" }}
        >
          <p
            className="text-[13px]"
            style={{ color: "rgba(255,255,255,0.4)" }}
          >
            &copy; 2026 ASAS Real Estate. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <a
              href="#"
              className="text-[13px] transition-colors duration-200 hover:text-white"
              style={{ color: "rgba(255,255,255,0.4)" }}
            >
              Privacy Policy
            </a>
            <a
              href="#"
              className="text-[13px] transition-colors duration-200 hover:text-white"
              style={{ color: "rgba(255,255,255,0.4)" }}
            >
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
