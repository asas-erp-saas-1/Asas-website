import { useEffect, useRef } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";

export default function GlassCubeOrb() {
  const mountRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const parent = mountRef.current;
    if (!parent) return;
    if (parent.children.length > 0) return;

    parent.innerHTML = "";
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0xffffff, 0.15);

    const camera = new THREE.PerspectiveCamera(
      45,
      parent.clientWidth / parent.clientHeight,
      0.1,
      100
    );
    camera.position.set(3, 0.5, 4);
    camera.lookAt(0, 0, 0);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(parent.clientWidth, parent.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    parent.appendChild(renderer.domElement);

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.03;
    controls.enablePan = false;
    controls.minDistance = 2;
    controls.maxDistance = 6;

    // Procedural noise texture
    const canvas = document.createElement("canvas");
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext("2d")!;
    const imgData = ctx.createImageData(256, 256);
    for (let i = 0; i < imgData.data.length; i += 4) {
      const val = Math.floor(Math.random() * 80 + 60);
      imgData.data[i] = val;
      imgData.data[i + 1] = val;
      imgData.data[i + 2] = val;
      imgData.data[i + 3] = 255;
    }
    ctx.putImageData(imgData, 0, 0);
    const noiseTexture = new THREE.CanvasTexture(canvas);
    noiseTexture.wrapS = THREE.RepeatWrapping;
    noiseTexture.wrapT = THREE.RepeatWrapping;

    const group = new THREE.Group();
    scene.add(group);

    // Main glass cube
    const geometry = new THREE.BoxGeometry(1.6, 1.6, 1.6);
    const glassMaterial = new THREE.MeshPhysicalMaterial({
      color: 0xc4d6b0,
      metalness: 0.1,
      roughness: 0.05,
      transmission: 0.95,
      thickness: 1.5,
      ior: 1.7,
      clearcoat: 1.0,
      clearcoatRoughness: 0.0,
      map: noiseTexture,
      transparent: true,
    });
    group.add(new THREE.Mesh(geometry, glassMaterial));

    // Outer wireframe icosahedron
    const outerGeo = new THREE.IcosahedronGeometry(2.8, 1);
    const outerMat = new THREE.MeshBasicMaterial({
      color: 0x04395e,
      wireframe: true,
      transparent: true,
      opacity: 0.08,
    });
    group.add(new THREE.Mesh(outerGeo, outerMat));

    // Inner cube
    const innerGeo = new THREE.BoxGeometry(1.1, 1.1, 1.1);
    const innerMat = new THREE.MeshPhysicalMaterial({
      color: 0xa1cca5,
      metalness: 0.4,
      roughness: 0.2,
      transmission: 0.6,
      thickness: 0.5,
      transparent: true,
      opacity: 0.3,
    });
    group.add(new THREE.Mesh(innerGeo, innerMat));

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.4);
    scene.add(ambientLight);

    const mainSpot = new THREE.SpotLight(0xffffff, 20, 20, 0.6, 0.8, 1.5);
    mainSpot.position.set(5, 5, 5);
    scene.add(mainSpot);

    const fillLight = new THREE.PointLight(0xd6f9dd, 8, 20);
    fillLight.position.set(-5, 2, -5);
    scene.add(fillLight);

    const backLight = new THREE.DirectionalLight(0xc4d6b0, 3);
    backLight.position.set(-5, 5, -5);
    backLight.target.position.set(0, 0, 0);
    scene.add(backLight);
    scene.add(backLight.target);

    // Environment
    const pmremGenerator = new THREE.PMREMGenerator(renderer);
    const envScene = new THREE.Scene();

    const envMaterial = new THREE.ShaderMaterial({
      uniforms: {
        topColor: { value: new THREE.Color(0xc4d6b0) },
        bottomColor: { value: new THREE.Color(0x04395e) },
        offset: { value: 33 },
        exponent: { value: 0.6 },
      },
      vertexShader: `
        varying vec3 vWorldPosition;
        void main() {
          vWorldPosition = (modelMatrix * vec4(position, 1.0)).xyz;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec3 vWorldPosition;
        uniform vec3 topColor;
        uniform vec3 bottomColor;
        uniform float offset;
        uniform float exponent;
        void main() {
          float h = normalize(vWorldPosition + offset).y;
          gl_FragColor = vec4(mix(bottomColor, topColor, max(pow(max(h, 0.0), exponent), 0.0)), 1.0);
        }
      `,
      side: THREE.BackSide,
    });

    const boxGeo = new THREE.BoxGeometry(100, 100, 100);
    envScene.add(new THREE.Mesh(boxGeo, envMaterial));
    scene.environment = pmremGenerator.fromScene(envScene, 0.04).texture;

    // Point light attached to camera
    const pointLight = new THREE.PointLight(0xffffff, 1, 10);
    camera.add(pointLight);
    scene.add(camera);

    let time = 0;

    const animate = () => {
      requestAnimationFrame(animate);
      time += 0.005;
      group.rotation.y = time * 0.5;
      group.rotation.x = Math.sin(time * 0.3) * 0.2;
      group.rotation.z = Math.cos(time * 0.2) * 0.1;
      controls.update();
      renderer.render(scene, camera);
    };

    const onResize = () => {
      const w = parent.clientWidth;
      const h = parent.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", onResize);

    animate();

    return () => {
      window.removeEventListener("resize", onResize);
      renderer.dispose();
      if (parent.contains(renderer.domElement)) {
        parent.removeChild(renderer.domElement);
      }
    };
  }, []);

  return (
    <div
      ref={mountRef}
      style={{
        width: "100%",
        height: "600px",
        position: "relative",
      }}
    />
  );
}
