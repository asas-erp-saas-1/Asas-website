import { MessageCircle } from "lucide-react";

export default function WhatsAppCTA() {
  const phoneNumber = "213550000000";
  const message = encodeURIComponent(
    "Hello ASAS Real Estate, I would like to inquire about your luxury properties."
  );

  return (
    <a
      href={`https://wa.me/${phoneNumber}?text=${message}`}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-6 z-50 flex items-center gap-3 px-5 py-3.5 text-white font-medium text-sm transition-all duration-300 hover:scale-105 hover:shadow-xl"
      style={{
        background: "linear-gradient(90deg, #25D366 0%, #128C7E 100%)",
        borderRadius: 50,
        boxShadow: "0 4px 16px rgba(37, 211, 102, 0.3)",
      }}
    >
      <MessageCircle size={22} fill="white" />
      <span className="hidden sm:inline">Contact on WhatsApp</span>
    </a>
  );
}
