import { useState, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Menu, X } from "lucide-react";

const navLinks = [
  { label: "Home", path: "/" },
  { label: "Properties", path: "/properties" },
  { label: "Services", path: "/services" },
  { label: "Agents", path: "/about" },
  { label: "About", path: "/about" },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 80);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  const isActive = (path: string) => {
    if (path === "/about") {
      return location.pathname === "/about";
    }
    return location.pathname === path;
  };

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        height: 80,
        borderBottom: "1px solid rgba(200,200,200,0.5)",
        background: scrolled ? "rgba(255,255,255,0.92)" : "#fff",
        backdropFilter: scrolled ? "blur(12px)" : "none",
      }}
    >
      <div className="max-w-[1200px] mx-auto px-6 h-full flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex flex-col items-start">
          <span
            className="font-display text-[22px] font-semibold tracking-tight"
            style={{ color: "var(--deep-teal)" }}
          >
            ASAS
          </span>
          <span
            className="text-[11px] font-light tracking-[0.1em]"
            style={{ color: "var(--taupe)" }}
          >
            Real Estate
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.label}
              to={link.path}
              className={`nav-link ${isActive(link.path) ? "active" : ""}`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* CTA Button */}
        <div className="hidden md:block">
          <button
            onClick={() => navigate("/consultation")}
            className="text-sm font-medium text-white px-7 transition-all duration-300 hover:scale-[1.03] hover:shadow-lg"
            style={{
              height: 44,
              background: "linear-gradient(90deg, #04395E 0%, #013A63 100%)",
              borderRadius: 2,
            }}
          >
            Visit Now
          </button>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="md:hidden p-2"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? (
            <X size={24} style={{ color: "var(--deep-teal)" }} />
          ) : (
            <Menu size={24} style={{ color: "var(--deep-teal)" }} />
          )}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div
          className="md:hidden absolute top-[80px] left-0 right-0 bg-white shadow-lg py-6 px-6"
          style={{ borderTop: "1px solid rgba(200,200,200,0.3)" }}
        >
          <nav className="flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.label}
                to={link.path}
                className="text-base font-medium py-2"
                style={{ color: "var(--deep-navy)" }}
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <button
              onClick={() => {
                setMobileOpen(false);
                navigate("/consultation");
              }}
              className="btn-primary mt-4 w-full"
            >
              Visit Now
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
