import { Link } from "react-router-dom";
import { MapPin, Bed, Bath, Maximize, ArrowRight } from "lucide-react";
import type { Property } from "@/data/properties";

interface PropertyCardProps {
  property: Property;
}

export default function PropertyCard({ property }: PropertyCardProps) {
  return (
    <Link to={`/properties/${property.id}`} className="property-card group block bg-white rounded overflow-hidden" style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.06)" }}>
      {/* Image */}
      <div className="relative overflow-hidden" style={{ aspectRatio: "4/3" }}>
        <img
          src={property.image}
          alt={property.title}
          className="property-image w-full h-full object-cover"
          loading="lazy"
        />
        {/* Badge */}
        <div
          className="absolute top-3 right-3 px-3.5 py-1.5 text-[11px] font-medium uppercase tracking-wider text-white"
          style={{ background: "var(--deep-teal)", borderRadius: 2 }}
        >
          {property.type}
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        <h4
          className="font-display text-lg mb-1.5 group-hover:opacity-80 transition-opacity"
          style={{ color: "var(--deep-teal)" }}
        >
          {property.title}
        </h4>

        <div className="flex items-center gap-1.5 mb-3">
          <MapPin size={14} style={{ color: "var(--taupe)" }} />
          <span className="text-sm" style={{ color: "var(--taupe)" }}>
            {property.location}
          </span>
        </div>

        <div className="flex items-center gap-4 mb-4">
          <div className="flex items-center gap-1">
            <Bed size={14} style={{ color: "var(--text-secondary)" }} />
            <span className="text-xs" style={{ color: "var(--text-secondary)" }}>
              {property.bedrooms}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <Bath size={14} style={{ color: "var(--text-secondary)" }} />
            <span className="text-xs" style={{ color: "var(--text-secondary)" }}>
              {property.bathrooms}
            </span>
          </div>
          <div className="flex items-center gap-1">
            <Maximize size={14} style={{ color: "var(--text-secondary)" }} />
            <span className="text-xs" style={{ color: "var(--text-secondary)" }}>
              {property.area} m²
            </span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <span
            className="text-lg font-medium"
            style={{ color: "var(--deep-teal)" }}
          >
            {property.price}
          </span>
          <span
            className="flex items-center gap-1 text-sm font-medium transition-all duration-200 group-hover:gap-2"
            style={{ color: "var(--deep-teal)" }}
          >
            Details
            <ArrowRight size={14} />
          </span>
        </div>
      </div>
    </Link>
  );
}
