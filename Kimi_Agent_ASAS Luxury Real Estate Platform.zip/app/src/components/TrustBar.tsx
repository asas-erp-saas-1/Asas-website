import { Shield, Award, Clock, Users } from "lucide-react";
import { useScrollFade } from "@/hooks/useScrollFade";

const trustItems = [
  { icon: Shield, label: "Licensed & Insured", desc: "Full legal compliance" },
  { icon: Award, label: "15+ Years", desc: "Market expertise" },
  { icon: Users, label: "500+ Clients", desc: "Satisfied customers" },
  { icon: Clock, label: "24/7 Support", desc: "Always available" },
];

export default function TrustBar() {
  const { ref, isVisible } = useScrollFade(0.1);

  return (
    <div
      ref={ref}
      className={`section-fade ${isVisible ? "visible" : ""} py-8 border-y`}
      style={{ background: "var(--light-mint)", borderColor: "var(--silver-sage)" }}
    >
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {trustItems.map(({ icon: Icon, label, desc }) => (
            <div key={label} className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                style={{ background: "var(--deep-teal)" }}
              >
                <Icon size={18} className="text-white" />
              </div>
              <div>
                <p className="text-sm font-medium" style={{ color: "var(--deep-teal)" }}>
                  {label}
                </p>
                <p className="text-xs" style={{ color: "var(--taupe)" }}>
                  {desc}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
