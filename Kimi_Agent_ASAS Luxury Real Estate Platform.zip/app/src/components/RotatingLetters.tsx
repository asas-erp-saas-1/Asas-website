export default function RotatingLetters() {
  const letters = ["A", "S", "A", "S"];

  return (
    <div className="perspective" style={{ height: "15vw", minHeight: 120 }}>
      <div className="rotating-gallery" style={{ height: "15vw", minHeight: 120 }}>
        {letters.map((letter, index) => (
          <div key={index} className={`letter letter-${index + 1}`}>
            <span>{letter}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
