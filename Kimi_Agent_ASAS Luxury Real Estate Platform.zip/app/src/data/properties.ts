export interface Property {
  id: number;
  title: string;
  location: string;
  price: string;
  priceValue: number;
  type: string;
  bedrooms: number;
  bathrooms: number;
  area: number;
  image: string;
  gallery: string[];
  description: string;
  features: string[];
  agent: string;
  agentImage: string;
  featured?: boolean;
}

export interface Agent {
  id: number;
  name: string;
  role: string;
  image: string;
  bio: string;
  phone: string;
  email: string;
  experience: string;
}

export interface Service {
  id: number;
  title: string;
  description: string;
  icon: string;
}

export interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  category: string;
  date: string;
  readTime: string;
  image: string;
}

export const properties: Property[] = [
  {
    id: 1,
    title: "Villa Oran",
    location: "Oran, Algeria",
    price: "64,000,000 DZD",
    priceValue: 64000000,
    type: "Villa",
    bedrooms: 5,
    bathrooms: 4,
    area: 450,
    image: "/images/property-1.jpg",
    gallery: ["/images/property-1.jpg", "/images/property-2.jpg", "/images/property-3.jpg"],
    description: "A magnificent Mediterranean villa offering panoramic sea views and unparalleled luxury living. This exquisite property features expansive living spaces, a private pool, and meticulously landscaped gardens. The architecture seamlessly blends modern comfort with traditional Algerian design elements.",
    features: ["Private Pool", "Sea View", "Garden", "Garage", "Security System", "Central Heating"],
    agent: "Malek Mahmoud",
    agentImage: "/images/agent-malek.jpg",
    featured: true,
  },
  {
    id: 2,
    title: "Appartement Oran",
    location: "Oran, Algeria",
    price: "55,000,000 DZD",
    priceValue: 55000000,
    type: "Apartment",
    bedrooms: 3,
    bathrooms: 2,
    area: 180,
    image: "/images/property-2.jpg",
    gallery: ["/images/property-2.jpg", "/images/property-1.jpg", "/images/property-4.jpg"],
    description: "An elegant waterfront apartment featuring floor-to-ceiling windows that frame breathtaking Mediterranean views. The interior showcases premium finishes, an open-plan layout, and access to exclusive building amenities.",
    features: ["Sea View", "Elevator", "Parking", "Concierge", "Fitness Center", "Terrace"],
    agent: "Lina Hamza",
    agentImage: "/images/agent-lina.jpg",
    featured: true,
  },
  {
    id: 3,
    title: "Oran Luxe",
    location: "Oran, Algeria",
    price: "120,000,000 DZD",
    priceValue: 120000000,
    type: "House",
    bedrooms: 6,
    bathrooms: 5,
    area: 680,
    image: "/images/property-3.jpg",
    gallery: ["/images/property-3.jpg", "/images/property-5.jpg", "/images/property-6.jpg"],
    description: "The pinnacle of luxury living in Oran. This architectural masterpiece commands stunning mountain and sea views from its expansive terraces. Every detail has been crafted to perfection, from the imported marble floors to the bespoke kitchen.",
    features: ["Infinity Pool", "Mountain View", "Smart Home", "Wine Cellar", "Home Theater", "Staff Quarters"],
    agent: "Malek Mahmoud",
    agentImage: "/images/agent-malek.jpg",
    featured: true,
  },
  {
    id: 4,
    title: "Villa Alger",
    location: "Algiers, Algeria",
    price: "55,000,000 DZD",
    priceValue: 55000000,
    type: "Villa",
    bedrooms: 4,
    bathrooms: 3,
    area: 320,
    image: "/images/property-4.jpg",
    gallery: ["/images/property-4.jpg", "/images/property-1.jpg", "/images/property-6.jpg"],
    description: "A charming Mediterranean villa perched above the Bay of Algiers. Bougainvillea-draped terraces, blue-shuttered windows, and panoramic bay views create an atmosphere of timeless elegance. Recently renovated with modern amenities while preserving its classic character.",
    features: ["Bay View", "Terrace Garden", "Fireplace", "Guest House", "Solar Panels", "Gated Entry"],
    agent: "Adel Kouider",
    agentImage: "/images/agent-adel.jpg",
  },
  {
    id: 5,
    title: "Villa Oran Premium",
    location: "Oran, Algeria",
    price: "150,000,000 DZD",
    priceValue: 150000000,
    type: "Villa",
    bedrooms: 7,
    bathrooms: 6,
    area: 850,
    image: "/images/property-5.jpg",
    gallery: ["/images/property-5.jpg", "/images/property-3.jpg", "/images/property-1.jpg"],
    description: "An ultra-luxurious modern villa with an infinity pool overlooking the Mediterranean. Expansive glass walls dissolve the boundary between interior and exterior, while the rooftop terrace offers 360-degree coastal views. The ultimate expression of contemporary Algerian luxury.",
    features: ["Infinity Pool", "Rooftop Terrace", "Private Beach Access", "Smart Home", "Elevator", "Home Cinema"],
    agent: "Rachid Mansour",
    agentImage: "/images/agent-rachid.jpg",
    featured: true,
  },
  {
    id: 6,
    title: "Villa Oran Heritage",
    location: "Oran, Algeria",
    price: "130,000,000 DZD",
    priceValue: 130000000,
    type: "Villa",
    bedrooms: 5,
    bathrooms: 4,
    area: 520,
    image: "/images/property-6.jpg",
    gallery: ["/images/property-6.jpg", "/images/property-4.jpg", "/images/property-2.jpg"],
    description: "A stunning fusion of traditional Algerian architecture and contemporary design. The central courtyard with its marble fountain serves as the heart of the home, surrounded by ornate ironwork, lush gardens, and warm earth-toned interiors.",
    features: ["Central Courtyard", "Fountain", "Ornate Ironwork", "Garden", "Traditional Craftsmanship", "Modern Kitchen"],
    agent: "Lina Hamza",
    agentImage: "/images/agent-lina.jpg",
  },
];

export const agents: Agent[] = [
  {
    id: 1,
    name: "Malek Mahmoud",
    role: "Senior Property Consultant",
    image: "/images/agent-malek.jpg",
    bio: "With over 15 years of experience in Algerian luxury real estate, Malek has facilitated transactions exceeding 5 billion DZD. His deep market knowledge and commitment to client satisfaction have made him one of the most sought-after consultants in Oran.",
    phone: "+213 550 000 001",
    email: "malek@asas-realestate.dz",
    experience: "15+ years",
  },
  {
    id: 2,
    name: "Lina Hamza",
    role: "Luxury Property Specialist",
    image: "/images/agent-lina.jpg",
    bio: "Lina brings a refined eye for premium properties and an extensive network of high-net-worth clients. Her expertise in waterfront and coastal properties has consistently delivered exceptional results for buyers and sellers alike.",
    phone: "+213 550 000 002",
    email: "lina@asas-realestate.dz",
    experience: "10+ years",
  },
  {
    id: 3,
    name: "Adel Kouider",
    role: "Investment Advisor",
    image: "/images/agent-adel.jpg",
    bio: "Adel specializes in real estate investment advisory, helping clients build diversified property portfolios. His analytical approach and market foresight have generated outstanding returns for investors across Algeria.",
    phone: "+213 550 000 003",
    email: "adel@asas-realestate.dz",
    experience: "8+ years",
  },
  {
    id: 4,
    name: "Rachid Mansour",
    role: "Managing Director",
    image: "/images/agent-rachid.jpg",
    bio: "As the founding director of ASAS Real Estate, Rachid has established the agency as the premier luxury property specialist in Algeria. His vision for excellence and integrity has shaped every aspect of the company's service philosophy.",
    phone: "+213 550 000 004",
    email: "rachid@asas-realestate.dz",
    experience: "25+ years",
  },
];

export const services: Service[] = [
  {
    id: 1,
    title: "Accurate Property Valuation",
    description: "Our certified valuation experts provide comprehensive property assessments using advanced market analysis and comparative evaluation methodologies. Receive a detailed report within 48 hours.",
    icon: "/images/icon-valuation.png",
  },
  {
    id: 2,
    title: "Personalized Property Tours",
    description: "Experience each property firsthand with a dedicated consultant who understands your preferences. We arrange private viewings at your convenience, including virtual tours for international clients.",
    icon: "/images/icon-tours.png",
  },
  {
    id: 3,
    title: "Expert Assistance",
    description: "From initial inquiry to final signing, our team manages every detail of your transaction. We coordinate with legal advisors, notaries, and financial institutions to ensure a seamless experience.",
    icon: "/images/icon-assistance.png",
  },
  {
    id: 4,
    title: "After-Sales Services",
    description: "Our commitment extends beyond the sale. We offer property management, renovation coordination, and ongoing support to ensure your investment maintains its value and your complete satisfaction.",
    icon: "/images/icon-aftersales.png",
  },
];

export const blogPosts: BlogPost[] = [
  {
    id: 1,
    title: "The Algerian Luxury Real Estate Market: 2026 Outlook",
    excerpt: "An in-depth analysis of market trends, price trajectories, and investment opportunities shaping Algeria's premium property sector this year.",
    category: "Market Analysis",
    date: "January 15, 2026",
    readTime: "8 min read",
    image: "/images/property-5.jpg",
  },
  {
    id: 2,
    title: "Why Oran is Becoming the Mediterranean's Hidden Gem",
    excerpt: "From coastal villas to urban penthouses, discover why discerning buyers are turning their attention to Oran's luxury property market.",
    category: "Location Guide",
    date: "January 8, 2026",
    readTime: "6 min read",
    image: "/images/property-3.jpg",
  },
  {
    id: 3,
    title: "Investing in Algerian Real Estate: A Complete Guide",
    excerpt: "Everything you need to know about property investment in Algeria, from legal frameworks to financing options and expected returns.",
    category: "Investment",
    date: "December 28, 2025",
    readTime: "12 min read",
    image: "/images/property-1.jpg",
  },
  {
    id: 4,
    title: "The Art of Mediterranean Architecture in Modern Algeria",
    excerpt: "Exploring how contemporary Algerian architects blend traditional Mediterranean elements with cutting-edge design.",
    category: "Architecture",
    date: "December 20, 2025",
    readTime: "7 min read",
    image: "/images/property-6.jpg",
  },
  {
    id: 5,
    title: "5 Features That Define a True Luxury Property",
    excerpt: "From smart home technology to private wellness facilities, discover the essential elements that separate luxury homes from the rest.",
    category: "Lifestyle",
    date: "December 12, 2025",
    readTime: "5 min read",
    image: "/images/property-4.jpg",
  },
  {
    id: 6,
    title: "Understanding Property Valuation in Algeria",
    excerpt: "A comprehensive guide to how properties are valued in Algeria and what factors influence premium property pricing.",
    category: "Guide",
    date: "December 5, 2025",
    readTime: "9 min read",
    image: "/images/property-2.jpg",
  },
];
